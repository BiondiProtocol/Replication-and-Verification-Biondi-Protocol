from __future__ import annotations

import argparse
from .config import load_config
from .pipeline import run


def main() -> None:
    parser = argparse.ArgumentParser(description="Run Generic Biondi Subaperture Tomography Protocol v1.7")
    parser.add_argument("config", help="Completed run configuration JSON")
    args = parser.parse_args()
    print(run(load_config(args.config)))


def validate_main() -> None:
    parser = argparse.ArgumentParser(description="Validate a Biondi v1.7 run configuration")
    parser.add_argument("config")
    args = parser.parse_args()
    load_config(args.config)
    print("Configuration is structurally valid.")
