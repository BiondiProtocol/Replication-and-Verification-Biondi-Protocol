from __future__ import annotations

import hashlib
from pathlib import Path
from typing import Any

import h5py
import numpy as np
import tifffile

from .errors import ProtocolError


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def load_complex_image(spec: dict[str, Any], base: Path) -> tuple[np.ndarray, dict[str, Any]]:
    path = (base / spec["path"]).resolve()
    if not path.exists():
        raise ProtocolError(f"Input file does not exist: {path}")
    observed_hash = sha256(path)
    if observed_hash.lower() != str(spec["sha256"]).lower():
        raise ProtocolError("Input SHA-256 mismatch; refusing to run on an unverified acquisition.")
    fmt = str(spec["format"]).lower()
    if fmt == "npy":
        image = np.load(path)
    elif fmt in {"tif", "tiff", "geotiff"}:
        image = tifffile.imread(path)
    elif fmt in {"h5", "hdf5"}:
        dataset = spec.get("dataset_path")
        if not dataset:
            raise ProtocolError("HDF5 input requires input.dataset_path for the complex SLC array.")
        with h5py.File(path, "r") as handle:
            image = handle[dataset][...]
    else:
        raise ProtocolError(f"Unsupported input format: {fmt}")
    image = np.asarray(image)
    if image.ndim != 2 or not np.iscomplexobj(image):
        raise ProtocolError("The selected input must be a two-dimensional complex SLC array.")
    metadata = {"input_path": str(path), "sha256": observed_hash, "shape": list(image.shape), "format": fmt}
    return image.astype(np.complex128, copy=False), metadata
