"""Executable implementation of the Generic Biondi Subaperture Tomography Protocol v1.7."""

__version__ = "0.1.0"
