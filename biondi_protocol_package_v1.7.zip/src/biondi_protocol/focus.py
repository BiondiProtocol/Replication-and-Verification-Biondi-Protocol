from __future__ import annotations

import numpy as np


def focus_depth(q_arc: np.ndarray, kz: np.ndarray, spec: dict) -> dict:
    z = np.arange(float(spec["z_min_m"]), float(spec["z_max_m"]) + float(spec["z_step_m"])/2, float(spec["z_step_m"]))
    score = np.empty((q_arc.shape[0], len(z)), float)
    for zi, depth in enumerate(z):
        design = np.column_stack([np.cos(kz*depth), np.sin(kz*depth)])
        for x in range(q_arc.shape[0]):
            coef, *_ = np.linalg.lstsq(design, q_arc[x], rcond=None)
            pred = design @ coef
            score[x, zi] = 1 - np.sum((q_arc[x]-pred)**2)/(np.sum((q_arc[x]-q_arc[x].mean(axis=0))**2)+1e-15)
    return {"z_m": z, "score": score, "best_depth_m": z[np.argmax(score, axis=1)]}
