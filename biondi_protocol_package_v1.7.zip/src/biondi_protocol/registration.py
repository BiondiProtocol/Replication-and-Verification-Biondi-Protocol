from __future__ import annotations

import numpy as np
from scipy.ndimage import shift as nd_shift

from .errors import ProtocolError


def _window(center: tuple[int, int], size: int, shape: tuple[int, int]) -> tuple[slice, slice]:
    half = size // 2
    r, c = center
    if r-half < 0 or c-half < 0 or r+half > shape[0] or c+half > shape[1]:
        raise ProtocolError(f"Registration patch at {center} with size {size} exceeds image boundary.")
    return slice(r-half, r-half+size), slice(c-half, c-half+size)


def _integer_peak(reference: np.ndarray, offset: np.ndarray) -> tuple[float, float]:
    corr = np.fft.ifft2(np.fft.fft2(reference) * np.conj(np.fft.fft2(offset)))
    peak = np.unravel_index(np.argmax(np.abs(corr)), corr.shape)
    shifts = np.array(peak, dtype=float)
    for axis, n in enumerate(reference.shape):
        if shifts[axis] > n // 2:
            shifts[axis] -= n
    return float(shifts[0]), float(shifts[1])


def register_complex(reference: np.ndarray, offset: np.ndarray, center: tuple[int, int], spec: dict) -> dict:
    size = int(spec["patch_size_pixels"])
    rs, cs = _window(center, size, reference.shape)
    a, b = reference[rs, cs], offset[rs, cs]
    dy, dx = _integer_peak(a, b)
    # Quadratic sub-pixel peak refinement is intentionally conservative; retain the continuous estimate separately.
    aligned = nd_shift(b, shift=(dy, dx), order=3, mode="nearest", prefilter=False)
    score = abs(np.vdot(a, aligned)) / (np.linalg.norm(a) * np.linalg.norm(aligned) + 1e-15)
    return {"row_shift": dy, "column_shift": dx, "score": float(score), "rounded_row_shift": int(round(dy)), "rounded_column_shift": int(round(dx))}


def validate_registration(spec: dict) -> dict:
    n = max(32, int(spec["patch_size_pixels"]))
    rng = np.random.default_rng(7)
    reference = rng.normal(size=(n, n)) + 1j*rng.normal(size=(n, n))
    imposed = (2, -3)
    offset = nd_shift(reference, shift=imposed, order=0, mode="wrap")
    measured = register_complex(reference, offset, (n//2, n//2), {**spec, "patch_size_pixels": n})
    identity = register_complex(reference, reference, (n//2, n//2), {**spec, "patch_size_pixels": n})
    passed = (round(measured["row_shift"]) == -imposed[0] and round(measured["column_shift"]) == -imposed[1]
              and round(identity["row_shift"]) == 0 and round(identity["column_shift"]) == 0)
    return {"identity": identity, "imposed_shift": {"applied_to_offset_row_column": imposed, "measured": measured}, "passed": passed}
