from __future__ import annotations

import json
from dataclasses import asdict
from pathlib import Path
import numpy as np

from .config import RunConfig
from .errors import ProtocolError
from .filterbank import build_pair_bank, reconstruct_pairs
from .focus import focus_depth
from .geometry import kz_vector, recurrence_depth
from .io import load_complex_image
from .modal import fit_modes
from .registration import validate_registration
from .vectors import measure_vectors


def run(config: RunConfig) -> Path:
    out = (config.path.parent / config.run["output_directory"]).resolve()
    out.mkdir(parents=True, exist_ok=False)
    image, input_manifest = load_complex_image(config.input, config.path.parent)
    validation = validate_registration(config.registration)
    if not validation["passed"]:
        raise ProtocolError("Registration validation failed; no target processing was performed.")
    masks, pairs = build_pair_bank(config.bank, image.shape[int(config.input["azimuth_doppler_axis"])])
    ref, off = reconstruct_pairs(image, int(config.input["azimuth_doppler_axis"]), masks)
    vectors = measure_vectors(ref, off, config.vectors["target_track"], config.vectors["nuisance_arcs"], config.registration)
    modal = fit_modes(vectors["q_arc"], config.modal)
    kz = kz_vector(len(pairs), config.geometry)
    focus = focus_depth(vectors["q_arc"], kz, config.focus)
    np.savez_compressed(out / "results.npz", reference=ref, offset=off, kz=kz, modal_table=modal["table"], **vectors, **focus)
    manifest = {"protocol_version": "1.7", "run": config.run, "input": input_manifest,
                "pair_table": [p.record() for p in pairs], "registration_validation": validation,
                "nuisance_identity_error": vectors["identity_error"], "recurrence_depth_m": recurrence_depth(kz),
                "epistemic_status": "Registration vectors and nominal-depth scores are image-processing observables and conditional model fits, not physical-motion, void, penetration, or absolute-depth proof."}
    (out / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    (out / "config_used.json").write_text(json.dumps(config.raw, indent=2), encoding="utf-8")
    return out
