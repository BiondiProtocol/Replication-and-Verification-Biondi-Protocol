from __future__ import annotations

import numpy as np

from .errors import ProtocolError


def kz_vector(pair_count: int, spec: dict) -> np.ndarray:
    b = np.asarray(spec["baseline_perp_m"], dtype=float)
    if b.ndim == 0:
        b = np.linspace(-float(b)/2, float(b)/2, pair_count)
    if len(b) != pair_count:
        raise ProtocolError("geometry.baseline_perp_m must be a scalar aperture span or one value per pair.")
    r = float(spec["slant_range_m"]); theta = np.deg2rad(float(spec["incidence_angle_deg"])); lam = float(spec["operational_wavelength_m"])
    if r <= 0 or lam <= 0 or not 0 < theta < np.pi/2:
        raise ProtocolError("Invalid slant range, incidence angle, or operational wavelength.")
    return 4*np.pi*b/(lam*r*np.sin(theta))


def recurrence_depth(kz: np.ndarray) -> float | None:
    diffs = np.diff(np.sort(np.unique(kz)))
    diffs = diffs[np.abs(diffs) > 1e-15]
    return None if not len(diffs) else float(2*np.pi/np.median(np.abs(diffs)))
