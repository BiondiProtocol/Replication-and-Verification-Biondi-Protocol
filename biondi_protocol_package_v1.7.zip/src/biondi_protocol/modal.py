from __future__ import annotations

import numpy as np


def fit_modes(q_arc: np.ndarray, spec: dict) -> dict:
    k_count = q_arc.shape[1]
    window = int(spec["window_length_w"])
    modes = range(int(spec["mode_min"]), int(spec["mode_max"]) + 1)
    if not 3 <= window <= k_count:
        raise ValueError("window_length_w must be between 3 and the pair count.")
    rows = []
    for x in range(q_arc.shape[0]):
        for start in range(k_count - window + 1):
            y = q_arc[x, start:start+window]
            n = np.arange(window)
            for m in modes:
                design = np.column_stack([np.ones(window), np.cos(2*np.pi*m*n/window), np.sin(2*np.pi*m*n/window)])
                coef, *_ = np.linalg.lstsq(design, y, rcond=None)
                pred = design @ coef
                ss_res = float(np.sum((y-pred)**2)); ss_tot = float(np.sum((y-y.mean(axis=0))**2))
                r2 = 1.0 - ss_res/(ss_tot+1e-15)
                ellipse = coef[1:3].T
                singular = np.linalg.svd(ellipse, compute_uv=False)
                ratio = float(singular[-1]/(singular[0]+1e-15))
                rows.append((x, start, m, r2, float(np.sqrt(np.mean((pred-y)**2))), float(singular[0]), float(singular[-1]), ratio))
    dtype = [("position", "i4"), ("window_start", "i4"), ("mode", "i4"), ("r2", "f8"), ("rms", "f8"), ("major", "f8"), ("minor", "f8"), ("axis_ratio", "f8")]
    return {"table": np.array(rows, dtype=dtype)}
