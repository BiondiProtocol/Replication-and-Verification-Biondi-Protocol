class ProtocolError(RuntimeError):
    """Raised when a run violates a required protocol gate."""
