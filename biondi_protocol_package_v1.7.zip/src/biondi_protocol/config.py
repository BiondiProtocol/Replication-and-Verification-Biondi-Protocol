from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .errors import ProtocolError


def _need(mapping: dict[str, Any], key: str, where: str) -> Any:
    value = mapping.get(key)
    if value is None or value == "":
        raise ProtocolError(f"Missing required setting: {where}.{key}")
    return value


@dataclass(frozen=True)
class RunConfig:
    raw: dict[str, Any]
    path: Path

    @property
    def run(self) -> dict[str, Any]:
        return self.raw["run"]

    @property
    def input(self) -> dict[str, Any]:
        return self.raw["input"]

    @property
    def bank(self) -> dict[str, Any]:
        return self.raw["frequency_domain_pair_bank"]

    @property
    def registration(self) -> dict[str, Any]:
        return self.raw["registration"]

    @property
    def vectors(self) -> dict[str, Any]:
        return self.raw["vectors"]

    @property
    def modal(self) -> dict[str, Any]:
        return self.raw["modal_analysis"]

    @property
    def geometry(self) -> dict[str, Any]:
        return self.raw["geometry"]

    @property
    def focus(self) -> dict[str, Any]:
        return self.raw["depth_focus"]

    def validate(self) -> None:
        if self.raw.get("protocol_version") != "1.7":
            raise ProtocolError("This runner requires protocol_version '1.7'.")
        for group in ("run", "input", "frequency_domain_pair_bank", "registration", "vectors", "modal_analysis", "geometry", "depth_focus"):
            if not isinstance(self.raw.get(group), dict):
                raise ProtocolError(f"Missing configuration object: {group}")
        _need(self.run, "output_directory", "run")
        for key in ("path", "format", "sha256", "azimuth_doppler_axis", "range_axis"):
            _need(self.input, key, "input")
        if {self.input["azimuth_doppler_axis"], self.input["range_axis"]} != {0, 1}:
            raise ProtocolError("input axes must be 0 and 1, one each.")
        for key in ("frequency_min_hz", "frequency_max_hz", "fft_length", "passband_width_hz", "b_shift_hz", "pair_count_k"):
            _need(self.bank, key, "frequency_domain_pair_bank")
        if not 0 < float(self.bank.get("maximum_successive_overlap_fraction", 0.05)) < 1:
            raise ProtocolError("maximum_successive_overlap_fraction must be between 0 and 1.")
        for key in ("patch_size_pixels", "context_margin_pixels", "upsample_factor"):
            _need(self.registration, key, "registration")
        _need(self.vectors, "target_track", "vectors")
        _need(self.vectors, "nuisance_arcs", "vectors")
        for key in ("mode_min", "mode_max", "window_length_w"):
            _need(self.modal, key, "modal_analysis")
        for key in ("slant_range_m", "incidence_angle_deg", "baseline_perp_m", "operational_wavelength_m"):
            _need(self.geometry, key, "geometry")
        for key in ("z_min_m", "z_max_m", "z_step_m"):
            _need(self.focus, key, "depth_focus")


def load_config(path: str | Path) -> RunConfig:
    path = Path(path).resolve()
    with path.open("r", encoding="utf-8") as handle:
        raw = json.load(handle)
    config = RunConfig(raw=raw, path=path)
    config.validate()
    return config
