from __future__ import annotations

import numpy as np

from .errors import ProtocolError
from .registration import register_complex


def _points(track: list) -> list[tuple[int, int]]:
    points = []
    for p in track:
        if not (isinstance(p, list) and len(p) == 2):
            raise ProtocolError("Track points must be [row, column].")
        points.append((int(p[0]), int(p[1])))
    if not points:
        raise ProtocolError("A target track must contain at least one point.")
    return points


def measure_vectors(reference: np.ndarray, offset: np.ndarray, track: list, arcs: list, registration: dict) -> dict:
    target = _points(track)
    arc_points = [_points(arc) for arc in arcs]
    if len(arc_points) < 2:
        raise ProtocolError("At least two nuisance arcs/flanks are required.")
    k_count = reference.shape[0]
    y = np.empty((len(target), k_count, 2), float)
    nuisance = np.empty((len(arc_points), max(map(len, arc_points)), k_count, 2), float)
    nuisance.fill(np.nan)
    score = np.empty((len(target), k_count), float)
    for k in range(k_count):
        for i, point in enumerate(target):
            r = register_complex(reference[k], offset[k], point, registration)
            y[i, k] = (r["column_shift"], r["row_shift"])
            score[i, k] = r["score"]
        for side, arc in enumerate(arc_points):
            for j, point in enumerate(arc):
                r = register_complex(reference[k], offset[k], point, registration)
                nuisance[side, j, k] = (r["column_shift"], r["row_shift"])
    side_summary = np.nanmedian(nuisance, axis=1)
    g_arc = np.nanmean(side_summary, axis=0)
    q_arc = y - g_arc[None, :, :]
    identity_error = float(np.nanmax(np.abs(y - (g_arc[None, :, :] + q_arc))))
    if identity_error > 1e-10:
        raise ProtocolError("Nuisance identity Y = G_arc + q_arc failed.")
    return {"Y": y, "nuisance": nuisance, "G_arc": g_arc, "q_arc": q_arc, "registration_score": score, "identity_error": identity_error}
