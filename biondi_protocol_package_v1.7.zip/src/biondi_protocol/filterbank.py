from __future__ import annotations

from dataclasses import dataclass, asdict
import numpy as np

from .errors import ProtocolError


@dataclass(frozen=True)
class PairMask:
    index: int
    reference_low_hz: float
    reference_high_hz: float
    offset_low_hz: float
    offset_high_hz: float
    realized_b_shift_hz: float
    successive_offset_overlap_hz: float
    successive_offset_overlap_fraction: float

    def record(self) -> dict:
        return asdict(self)


def _overlap(a0: float, a1: float, b0: float, b1: float) -> float:
    return max(0.0, min(a1, b1) - max(a0, b0))


def build_pair_bank(spec: dict, axis_length: int) -> tuple[np.ndarray, list[PairMask]]:
    fmin, fmax = float(spec["frequency_min_hz"]), float(spec["frequency_max_hz"])
    width, shift, count = float(spec["passband_width_hz"]), float(spec["b_shift_hz"]), int(spec["pair_count_k"])
    alpha = float(spec.get("maximum_successive_overlap_fraction", 0.05))
    advance = float(spec.get("edge_advance_hz", (1.0 - alpha) * shift))
    if width <= 0 or shift <= 0 or count < 2 or advance <= 0:
        raise ProtocolError("Invalid pair-bank width, shift, count, or edge advance.")
    freqs = np.fft.fftshift(np.fft.fftfreq(axis_length, d=1.0 / (fmax - fmin))) + (fmin + fmax) / 2
    masks, records = [], []
    for k in range(count):
        r0 = float(spec.get("reference_start_hz", fmin)) + k * advance
        r1, o0, o1 = r0 + width, r0 + shift, r0 + shift + width
        if r0 < fmin or o1 > fmax:
            raise ProtocolError(f"Pair {k} exceeds declared processed spectral support.")
        # v1.7 constrains the successive *Offset-edge spans* of width B_shift,
        # not the broad Offset passbands themselves.  For pair k that span is
        # the interval from the corresponding Reference edge to its Offset edge.
        overlap = 0.0 if k == 0 else _overlap(records[-1].reference_low_hz, records[-1].offset_low_hz, r0, o0)
        fraction = overlap / shift
        if k and fraction > alpha + 1e-12:
            raise ProtocolError(f"Pair {k} violates successive Offset-edge overlap: {fraction:.6f} > {alpha:.6f}.")
        reference = ((freqs >= r0) & (freqs <= r1)).astype(float)
        offset = ((freqs >= o0) & (freqs <= o1)).astype(float)
        if not reference.any() or not offset.any():
            raise ProtocolError(f"Pair {k} is empty after discrete-bin rounding.")
        masks.append(np.stack([reference, offset]))
        records.append(PairMask(k, r0, r1, o0, o1, o0-r0, overlap, fraction))
    return np.asarray(masks), records


def reconstruct_pairs(image: np.ndarray, doppler_axis: int, masks: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    moved = np.moveaxis(image, doppler_axis, 0)
    spectrum = np.fft.fftshift(np.fft.fft(moved, axis=0), axes=0)
    ref, off = [], []
    for rmask, omask in masks:
        r = np.fft.ifft(np.fft.ifftshift(spectrum * rmask[:, None], axes=0), axis=0)
        o = np.fft.ifft(np.fft.ifftshift(spectrum * omask[:, None], axes=0), axis=0)
        ref.append(np.moveaxis(r, 0, doppler_axis))
        off.append(np.moveaxis(o, 0, doppler_axis))
    return np.asarray(ref), np.asarray(off)
