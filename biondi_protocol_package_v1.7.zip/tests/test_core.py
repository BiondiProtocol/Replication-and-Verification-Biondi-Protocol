import hashlib
import json

import numpy as np

from biondi_protocol.config import RunConfig
from biondi_protocol.filterbank import build_pair_bank
from biondi_protocol.geometry import kz_vector
from biondi_protocol.pipeline import run
from biondi_protocol.registration import validate_registration


def test_overlap_rule_is_enforced():
    spec = {"frequency_min_hz": 0, "frequency_max_hz": 10000, "passband_width_hz": 1000,
            "b_shift_hz": 400, "pair_count_k": 3, "maximum_successive_overlap_fraction": .05,
            "reference_start_hz": 0}
    _, table = build_pair_bank(spec, 512)
    assert max(p.successive_offset_overlap_fraction for p in table[1:]) <= .05


def test_registration_controls_pass():
    assert validate_registration({"patch_size_pixels": 32})["passed"]


def test_kz_has_one_value_per_pair():
    kz = kz_vector(5, {"baseline_perp_m": 1000, "slant_range_m": 600000,
                        "incidence_angle_deg": 35, "operational_wavelength_m": .24})
    assert kz.shape == (5,)


def test_end_to_end_run(tmp_path):
    rng = np.random.default_rng(2)
    slc = rng.normal(size=(128, 200)) + 1j*rng.normal(size=(128, 200))
    slc_path = tmp_path / "slc.npy"
    np.save(slc_path, slc)
    digest = hashlib.sha256(slc_path.read_bytes()).hexdigest()
    raw = {
        "protocol_version": "1.7", "run": {"output_directory": "out"},
        "input": {"path": "slc.npy", "format": "npy", "sha256": digest, "azimuth_doppler_axis": 0, "range_axis": 1},
        "frequency_domain_pair_bank": {"frequency_min_hz": -1000, "frequency_max_hz": 1000, "fft_length": 128, "passband_width_hz": 500, "b_shift_hz": 100, "pair_count_k": 3, "reference_start_hz": -1000},
        "registration": {"patch_size_pixels": 32, "context_margin_pixels": 64, "upsample_factor": 100},
        "vectors": {"target_track": [[64, 100]], "nuisance_arcs": [[[64, 40]], [[64, 160]]]},
        "modal_analysis": {"mode_min": 1, "mode_max": 2, "window_length_w": 3},
        "geometry": {"slant_range_m": 600000, "incidence_angle_deg": 35, "baseline_perp_m": 1000, "operational_wavelength_m": .24},
        "depth_focus": {"z_min_m": 0, "z_max_m": 2, "z_step_m": 1}
    }
    config_path = tmp_path / "run.json"
    config_path.write_text(json.dumps(raw))
    out = run(RunConfig(raw, config_path))
    assert (out / "manifest.json").exists() and (out / "results.npz").exists()
