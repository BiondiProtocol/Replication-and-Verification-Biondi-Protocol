#!/usr/bin/env python3
"""Create small ICEYE-style HDF5 and geometry files for the v1.8 integration test.

The files are synthetic test data only. They exercise HDF5 intake, pair-bank
construction, same-pair registration, nuisance correction, gates, Kz steering,
audit writing, and figure rendering. They are not a physical scene model.
"""

from __future__ import annotations

from datetime import datetime, timedelta, timezone
import json
from pathlib import Path

import h5py
import numpy as np


HERE = Path(__file__).parent
H5_PATH = HERE / "synthetic_iceye.h5"
GEOMETRY_PATH = HERE / "synthetic_geometry.json"


def main() -> None:
    rng = np.random.default_rng(18)
    rows, columns = 128, 96
    real = rng.standard_normal((rows, columns), dtype=np.float32)
    imaginary = rng.standard_normal((rows, columns), dtype=np.float32)
    epoch = datetime(2020, 1, 1, tzinfo=timezone.utc)
    times = [epoch + timedelta(seconds=value) for value in (0.0, 1.0, 2.0)]
    if H5_PATH.exists():
        H5_PATH.unlink()
    with h5py.File(H5_PATH, "w") as h5:
        h5.create_dataset("s_i", data=real)
        h5.create_dataset("s_q", data=imaginary)
        h5.create_dataset("azimuth_time_interval", data=0.005)
        h5.create_dataset("zerodoppler_start_utc", data=np.bytes_(epoch.isoformat()))
        h5.create_dataset("state_vector_time_utc", data=np.asarray([item.isoformat().encode("ascii") for item in times]))
        h5.create_dataset("posX", data=np.asarray([7000000.0, 7000000.0, 7000000.0]))
        h5.create_dataset("posY", data=np.asarray([0.0, 7500.0, 15000.0]))
        h5.create_dataset("posZ", data=np.asarray([0.0, 0.0, 0.0]))
        h5.create_dataset("velX", data=np.asarray([0.0, 0.0, 0.0]))
        h5.create_dataset("velY", data=np.asarray([7500.0, 7500.0, 7500.0]))
        h5.create_dataset("velZ", data=np.asarray([0.0, 0.0, 0.0]))
        h5.create_dataset("range_sampling_rate", data=1.0e7)
        h5.create_dataset("doppler_rate_coeffs", data=np.asarray([200.0]))
    geometry = {
        "title": "Synthetic ICEYE geometry for Version 1.8 integration test",
        "coordinate_order": "Geographic endpoints are [latitude, longitude]. Native pixels are [column, row].",
        "projection": {"height_m": 70.5},
        "target_samples_per_track": 5,
        "sides": {
            "Synthetic": {
                "P0_label": "west",
                "P_last_label": "east",
                "geographic_endpoint_lat_lon": [[29.976, 31.129], [29.976, 31.130]],
                "native_endpoints_col_row": [[20, 64], [70, 64]],
            }
        },
    }
    GEOMETRY_PATH.write_text(json.dumps(geometry, indent=2) + "\n", encoding="utf-8")
    print(H5_PATH)
    print(GEOMETRY_PATH)


if __name__ == "__main__":
    main()
