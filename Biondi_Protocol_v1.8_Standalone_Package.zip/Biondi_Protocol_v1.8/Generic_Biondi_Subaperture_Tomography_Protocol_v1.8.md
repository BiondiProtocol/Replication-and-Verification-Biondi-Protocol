# Biondi Subaperture Tomography Protocol Version 1.8

## Scope

Version 1.8 defines a reproducible single-acquisition workflow from a complex SAR SLC to registered vector observables, modal eligibility, and conditional nominal-depth focus. It supersedes Version 1.7 by packaging an executable reference implementation and by making the W-window eligibility hierarchy fully explicit.

The protocol does not establish physical motion, cavity identity, penetration, or absolute depth. It produces registered image-vector observables and conditional steering-model fit scores whose parameters, provenance, and limitations must be saved with every run.

## Standalone package contract

A Version 1.8 package contains:

1. one Python executable with no project-local imports;
2. a dependency list;
3. a fully declared run-profile JSON;
4. a geometry-data JSON schema;
5. data-free and synthetic integration checks; and
6. documentation of the exact output and audit arrays.

The executable accepts only the declared profile and its data files. Dataset paths, coordinate conventions, filter-bank choices, registration settings, gates, steering parameters, and output location must be visible in the profile or generated manifest.

## Input and geometry contract

The complex SLC must supply real and imaginary arrays, azimuth timing, zero-Doppler epoch, range sampling rate, Doppler-rate coefficients, and state-vector time, position, and velocity arrays. The profile maps all HDF5 paths explicitly.

Every target trace is frozen in native SLC coordinates before analysis. Geometry stores native pixels as [column, row] and geographic endpoints as [latitude, longitude]. The executable changes to [row, column] only for array indexing and records that conversion in the manifest.

The profile must declare the height used to derive each track's geodetic midpoint. This height, the native trace hash, and the source SLC SHA-256 are required audit identities.

## Pair-bank construction

For each ordered pair k, construct matched Reference and Offset Doppler masks on the declared Doppler axis. Record every continuous mask interval, discrete-bin count, center frequency, B-shift, K leap, and realized overlap with the next Offset mask.

The Version 1.8 reference profile treats successive Offset-mask overlap as a recorded experimental variable rather than a hard acceptance gate. A profile may elect to enforce a declared overlap limit, but that choice must be visible before target interpretation. Spatial registration patches are not allocations to particular spectral-edge spans.

The reference implementation uses an axis-0 Doppler FFT with unity range-frequency response. A different transform or range-frequency response requires an explicit profile change and a matching reconstruction implementation.

## Same-pair complex registration

Only the Reference and Offset reconstruction of the same k are registered. No registration is chained between different k values.

The frozen ICEYE profile extracts a Context128 neighborhood and evaluates complex phase cross-correlation on the central 32x32 scoring patch with no intensity normalization and 100-fold subpixel refinement. Vectors are recorded in [column shift, row shift] order after half-away-from-zero lattice quantization.

Each run executes and records identity, reference-copy, and known imposed-shift controls before accepting the measured vectors. A failure is a run failure, not an omitted diagnostic.

## Canonical vector and nuisance correction

For target P and pair k, let the same-pair registration vector be:

\[
Y_k(P)=[\Delta x(P,k),\Delta y(P,k)].
\]

Measure the same vector estimator on two declared nuisance arcs. Form a two-dimensional geometric median within each arc, average the two side medians, and define:

\[
q_k(P)=Y_k(P)-G_{arc,k}.
\]

The identity \(Y=G_{arc}+q\) must be numerically checked and saved. Depth focus uses q; Y is retained as a control.

## Modal ellipse gate

Within each sliding W-pair window, fit each declared harmonic mode to both q-vector components using a constant, cosine, and sine basis. The profile must declare the tested mode range, the metric used to choose one winning mode, and all pass thresholds.

The supplied ICEYE X13 Khafre W50 profile chooses one winner from m=1 through m=10 and requires, for that winner:

\[
R^2_{adj,modal}\ge0.25,
\qquad b/a\ge0.10,
\qquad b_{minor}\ge0.005\text{ native pixel}.
\]

These are modal-ellipse gates. They are distinct from the conditional depth-focus adjusted R2.

## Track10 and central K confinement

Track10 is a temporal/window eligibility condition. At one P position, ten successive one-start-shifted W50 windows must all pass the modal ellipse gates and have the same winning mode. With W=50, a ten-window family spans 59 ordered K-pairs.

The supplied profile accepts only Track10 family starts 50 through 191. Consequently, the union of all pair contents of an accepted family remains inside K50 through K249. This is the central 200 of the 317 K-pair bank, about 63 percent of the full pair count.

An individual W50 start is Track10-eligible only because it is a member of such a passing family. It is not a pooled 10-window vector fit.

## Exact-start spatial support

Spatial support further restricts individual W50-start eligibility.

At one exact W50 start s, contiguous P positions must all be independently Track10-eligible and have the same winning mode. They may have entered Track10 eligibility through different ten-window families, but the individual start s and modal winner must be identical across the P run.

P=4 and P=5 mean four or five contiguous sampled P positions total. They are not flank counts, are not a symmetric footprint around one target point, and do not require neighboring positions to share focused depth, phase, or amplitude.

A Track10 family at P40 around starts 100 through 109 and a same-mode family at P41 around 200 through 209 supply no mutual P support. Only the intersection of exact individual W starts can enter depth focus.

## Conditional nominal-depth focus

For every accepted W start s and every candidate nominal depth z, select the matching 50 q vectors and the matching 50 Kz coefficients. Do not slide one q window against an unrelated K block.

For components c=1,2, estimate:

\[
q_{k,c}\approx a_c\cos(K_{z,k}z)+b_c\sin(K_{z,k}z),
\qquad k=s,\ldots,s+W-1.
\]

The depth-score degrees of freedom are 100 scalar observations and four fitted coefficients for W=50. The implementation computes adjusted R2 from the residual relative to the within-window q variance. It saves every accepted-start candidate only through complete audit arrays and stores, at every retained (P,z), the individual W start that supplied the maximum score:

\[
S(P,z)=\max_{s\in\mathcal A(P)}R^2_{adj}(P,z;s).
\]

There is no sum, mean, or automatic reward for the number of redundant W starts. Different accepted starts can win at different depths at the same P position. A single W start can also produce periodic steering companions, which must not be counted as independent depth solutions.

## Kz geometry and depth statement

For each track, recompute the virtual aperture-plane baseline from current state vectors and the declared target midpoint. The reference implementation uses:

\[
K_{z,k}=\frac{4\pi B_{\perp,k}}{\lambda_{operational}r\sin\theta}.
\]

The profile records the operational wavelength, slant range, incidence, Kz span, and recurrence based on the median Kz increment. The z grid is nominal model depth. A calibration anchor does not independently validate an absolute physical depth scale.

## Required audit package

Every full run writes a manifest, resolved profile, complete R/O pair table, filter masks, registration controls, raw Y, nuisance arcs, G_arc, q, registration errors, modal metrics, Track10 masks, P-support masks, Kz and baseline arrays, all displayed and undisplayed depth scores, exact z grid, and winning W-start identities.

Figures may clip display values to 0 through 1, but the numerical audit must preserve unsupported NaNs and negative adjusted scores without smoothing or renormalization.

## Execution order

1. Validate profile and input HDF5 schema.
2. Hash SLC and frozen geometry.
3. Freeze target and nuisance-arc sample coordinates.
4. Construct and record the full R/O bank.
5. Reconstruct each matched pair and pass registration controls.
6. Measure Y, nuisance arcs, G_arc, and q.
7. Compute modal winners and ellipse gates for every sliding W start.
8. Apply Track10, central-family, and exact-start P support gates.
9. Recompute Kz from the current acquisition geometry.
10. Fit conditional depth focus at every accepted W start and z.
11. Save the complete audit and figures before interpretation.

## Interpretation boundary

Conditional adjusted R2 is a normalized within-window model-fit score. It is not amplitude, probability, a count of independent observations, or proof of a void. Repeated overlapping windows and neighboring P samples are dependent observations. Any physical interpretation must remain separate from the executable processing result and retain the audit lineage needed for reanalysis.
