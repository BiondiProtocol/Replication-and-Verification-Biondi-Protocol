#!/usr/bin/env python3
"""Standalone Biondi Protocol Version 1.8 reference implementation.

The executable has no project-local imports.  It accepts an ICEYE-style complex
SLC HDF5 file plus a frozen native-pixel geometry JSON, builds the declared
Reference/Offset bank, measures same-pair complex registrations, applies the
explicit W-window gates, and writes an auditable conditional-depth product.

The profile supplied with this package is the frozen ICEYE X13 / Khafre W50
profile.  Every acquisition- or experiment-specific setting is in JSON rather
than hidden in the code.  The implementation intentionally reports conditional
model-fit scores; it does not label them as physical depth or a detection
probability.
"""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import platform
import sys
import tempfile
import time
from typing import Any, Iterable

import h5py

os.environ.setdefault("MPLCONFIGDIR", str(Path(tempfile.gettempdir()) / "biondi_protocol_matplotlib"))
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import scipy
import skimage
from scipy.fft import fft, fftshift, ifft, ifftshift
from scipy.ndimage import fourier_shift
from skimage.registration import phase_cross_correlation


PACKAGE_VERSION = "1.8"
WGS84_A_M = 6378137.0
WGS84_F = 1.0 / 298.257223563


class ConfigurationError(ValueError):
    """Raised when a declared run profile cannot be executed safely."""


def json_default(value: Any) -> Any:
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.floating,)):
        return float(value)
    if isinstance(value, (np.ndarray,)):
        return value.tolist()
    if isinstance(value, Path):
        return str(value)
    raise TypeError(f"Cannot encode {type(value)!r} as JSON.")


def write_json(path: Path, value: Any) -> None:
    path.write_text(json.dumps(value, indent=2, default=json_default) + "\n", encoding="utf-8")


def read_json(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise ConfigurationError(f"Invalid JSON in {path}: {exc}") from exc
    if not isinstance(value, dict):
        raise ConfigurationError(f"{path} must contain a JSON object.")
    return value


def sha256_file(path: Path, chunk_bytes: int = 4 * 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        while True:
            chunk = stream.read(chunk_bytes)
            if not chunk:
                break
            digest.update(chunk)
    return digest.hexdigest()


def sha256_json(value: Any) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":")).encode("utf-8")).hexdigest()


def resolve_path(value: str | Path, parent: Path) -> Path:
    path = Path(value).expanduser()
    return path if path.is_absolute() else (parent / path).resolve()


def require(mapping: dict[str, Any], key: str, context: str) -> Any:
    if key not in mapping:
        raise ConfigurationError(f"Missing required field {context}.{key}.")
    return mapping[key]


def positive_float(value: Any, name: str) -> float:
    number = float(value)
    if not np.isfinite(number) or number <= 0.0:
        raise ConfigurationError(f"{name} must be a positive finite number.")
    return number


def nonnegative_float(value: Any, name: str) -> float:
    number = float(value)
    if not np.isfinite(number) or number < 0.0:
        raise ConfigurationError(f"{name} must be a non-negative finite number.")
    return number


def positive_int(value: Any, name: str) -> int:
    number = int(value)
    if number <= 0 or number != float(value):
        raise ConfigurationError(f"{name} must be a positive integer.")
    return number


def round_half_up(values: np.ndarray | float) -> np.ndarray:
    return np.floor(np.asarray(values, dtype=float) + 0.5).astype(int)


def quantize_half_away_from_zero(values: np.ndarray, factor: int) -> np.ndarray:
    values = np.asarray(values, dtype=float)
    return np.sign(values) * np.floor(np.abs(values) * factor + 0.5) / factor


def unit(vector: np.ndarray) -> np.ndarray:
    magnitude = float(np.linalg.norm(vector))
    if not np.isfinite(magnitude) or magnitude <= 0.0:
        raise ValueError("Cannot normalize a zero or non-finite vector.")
    return np.asarray(vector, dtype=float) / magnitude


def ecef_from_lla(latitude_deg: float, longitude_deg: float, height_m: float) -> np.ndarray:
    e2 = WGS84_F * (2.0 - WGS84_F)
    latitude = np.deg2rad(latitude_deg)
    longitude = np.deg2rad(longitude_deg)
    radius = WGS84_A_M / np.sqrt(1.0 - e2 * np.sin(latitude) ** 2)
    return np.array([
        (radius + height_m) * np.cos(latitude) * np.cos(longitude),
        (radius + height_m) * np.cos(latitude) * np.sin(longitude),
        (radius * (1.0 - e2) + height_m) * np.sin(latitude),
    ])


def ellipsoid_up(latitude_deg: float, longitude_deg: float) -> np.ndarray:
    latitude = np.deg2rad(latitude_deg)
    longitude = np.deg2rad(longitude_deg)
    return np.array([
        np.cos(latitude) * np.cos(longitude),
        np.cos(latitude) * np.sin(longitude),
        np.sin(latitude),
    ])


def parse_time(value: Any) -> float:
    array = np.asarray(value)
    if array.size == 1:
        value = array.reshape(-1)[0]
    if isinstance(value, (bytes, np.bytes_)):
        text = value.decode("ascii")
    else:
        text = str(value)
    if text.endswith("Z"):
        text = text[:-1] + "+00:00"
    parsed = datetime.fromisoformat(text)
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed.timestamp()


def interpolate_state(
    times: np.ndarray,
    positions: np.ndarray,
    velocities: np.ndarray,
    query_time: float,
) -> tuple[np.ndarray, np.ndarray]:
    if not (times[0] <= query_time <= times[-1]):
        raise ValueError(f"State-vector query {query_time} lies outside the supplied state-vector interval.")
    index = int(np.searchsorted(times, query_time, side="right") - 1)
    index = min(max(index, 0), len(times) - 2)
    fraction = (query_time - times[index]) / (times[index + 1] - times[index])
    position = positions[index] * (1.0 - fraction) + positions[index + 1] * fraction
    velocity = velocities[index] * (1.0 - fraction) + velocities[index + 1] * fraction
    return position, velocity


def nested(config: dict[str, Any], *keys: str) -> Any:
    value: Any = config
    location = "config"
    for key in keys:
        if not isinstance(value, dict) or key not in value:
            raise ConfigurationError(f"Missing required field {location}.{key}.")
        value = value[key]
        location += f".{key}"
    return value


def validate_config(config: dict[str, Any]) -> None:
    if str(require(config, "protocol_version", "config")) != PACKAGE_VERSION:
        raise ConfigurationError(f"This executable requires protocol_version {PACKAGE_VERSION}.")
    datasets = nested(config, "input", "hdf5_datasets")
    required_dataset_keys = (
        "real", "imaginary", "azimuth_time_interval", "zero_doppler_start_utc",
        "state_vector_time_utc", "position_x", "position_y", "position_z",
        "velocity_x", "velocity_y", "velocity_z", "range_sampling_rate",
        "doppler_rate_coefficients",
    )
    for key in required_dataset_keys:
        require(datasets, key, "input.hdf5_datasets")

    processing = nested(config, "processing")
    crop = require(processing, "source_crop", "processing")
    positive_int(require(crop, "rows", "processing.source_crop"), "processing.source_crop.rows")
    positive_int(require(crop, "max_columns", "processing.source_crop"), "processing.source_crop.max_columns")
    bank = require(processing, "filter_bank", "processing")
    for key in ("support_hz", "mask_width_hz", "bshift_hz", "k_leap_hz"):
        positive_float(require(bank, key, "processing.filter_bank"), f"processing.filter_bank.{key}")
    positive_int(require(bank, "pair_count", "processing.filter_bank"), "processing.filter_bank.pair_count")
    policy = str(require(bank, "successive_offset_overlap_policy", "processing.filter_bank"))
    if policy not in {"record_only", "enforce"}:
        raise ConfigurationError("successive_offset_overlap_policy must be record_only or enforce.")
    if policy == "enforce":
        limit = positive_float(require(bank, "successive_offset_overlap_fraction_limit", "processing.filter_bank"), "overlap limit")
        if limit > 1.0:
            raise ConfigurationError("successive_offset_overlap_fraction_limit must not exceed one.")

    registration = require(processing, "registration", "processing")
    context = positive_int(require(registration, "context_patch_pixels", "processing.registration"), "context patch")
    scoring = positive_int(require(registration, "scoring_patch_pixels", "processing.registration"), "scoring patch")
    if context < scoring or context % 2 or scoring % 2:
        raise ConfigurationError("Context and scoring patches must be even, and context must be at least scoring size.")
    positive_int(require(registration, "upsample_factor", "processing.registration"), "upsample factor")

    nuisance = require(processing, "nuisance_correction", "processing")
    positive_int(require(nuisance, "arc_samples_per_side", "processing.nuisance_correction"), "arc samples")
    positive_float(require(nuisance, "arc_offset_native_pixels", "processing.nuisance_correction"), "arc offset")

    gates = nested(config, "gates")
    window = positive_int(require(gates, "window_pairs", "gates"), "gates.window_pairs")
    pair_count = int(bank["pair_count"])
    if window > pair_count:
        raise ConfigurationError("gates.window_pairs cannot exceed filter-bank pair_count.")
    modes = require(gates, "mode_range", "gates")
    if not isinstance(modes, list) or len(modes) != 2 or int(modes[0]) < 1 or int(modes[1]) < int(modes[0]):
        raise ConfigurationError("gates.mode_range must be [positive minimum, maximum].")
    tracks = positive_int(require(gates, "same_mode_contiguous_windows", "gates"), "Track10 count")
    if tracks > pair_count - window + 1:
        raise ConfigurationError("Track count cannot exceed the number of W-window starts.")
    start_range = require(gates, "central_track_family_start_range", "gates")
    if not isinstance(start_range, list) or len(start_range) != 2:
        raise ConfigurationError("central_track_family_start_range must be [first, last].")
    first, last = int(start_range[0]), int(start_range[1])
    raw_starts = pair_count - window + 1
    if first < 0 or last < first or last + tracks > raw_starts:
        raise ConfigurationError("Central Track family start range falls outside the available W-window starts.")
    for support in require(gates, "pixel_support_variants", "gates"):
        positive_int(support, "pixel support")
    for key in ("ellipse_adjusted_r2_min", "ellipse_minor_semiaxis_min_native_pixel", "ellipse_axis_ratio_min"):
        positive_float(require(gates, key, "gates"), f"gates.{key}")

    steering = nested(config, "steering")
    nonnegative_float(require(steering, "target_height_m", "steering"), "steering.target_height_m")
    positive_float(require(steering, "operational_wavelength_m", "steering"), "steering.operational_wavelength_m")
    depth = require(steering, "depth_grid_m", "steering")
    z0 = float(require(depth, "minimum", "steering.depth_grid_m"))
    z1 = float(require(depth, "maximum", "steering.depth_grid_m"))
    step = positive_float(require(depth, "step", "steering.depth_grid_m"), "steering.depth_grid_m.step")
    if z0 < 0.0 or z1 <= z0 or not np.isfinite(z0 + z1 + step):
        raise ConfigurationError("Depth grid must be finite, non-negative, and increasing.")


def sample_trace(trace_col_row: np.ndarray, count: int) -> np.ndarray:
    if trace_col_row.ndim != 2 or trace_col_row.shape[1] != 2 or len(trace_col_row) < 2:
        raise ConfigurationError("A native trace must contain at least two [column, row] points.")
    indices = round_half_up(np.linspace(0, len(trace_col_row) - 1, count))
    return trace_col_row[indices]


def rasterized_trace_from_endpoints(endpoints_col_row: Iterable[Iterable[float]], count: int = 10001) -> np.ndarray:
    endpoints = np.asarray(list(endpoints_col_row), dtype=float)
    if endpoints.shape != (2, 2):
        raise ConfigurationError("native_endpoints_col_row must contain two [column, row] points.")
    return round_half_up(np.linspace(endpoints[0], endpoints[1], count))


def make_track_and_arcs(trace_col_row: np.ndarray, target_samples: int, arc_samples: int, arc_offset: float) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    target_col_row = sample_trace(trace_col_row, target_samples)
    target_row_col = target_col_row[:, ::-1]
    start = target_row_col[0].astype(float)
    end = target_row_col[-1].astype(float)
    direction = unit(end - start)
    normal = np.array([-direction[1], direction[0]])
    arc_indices = round_half_up(np.linspace(0, len(target_row_col) - 1, arc_samples + 2)[1:-1])
    arc_base = target_row_col[arc_indices].astype(float)
    plus = round_half_up(arc_base + arc_offset * normal)
    minus = round_half_up(arc_base - arc_offset * normal)
    return target_row_col.astype(int), plus.astype(int), minus.astype(int)


def geometry_tracks(geometry: dict[str, Any], config: dict[str, Any]) -> tuple[list[str], dict[str, dict[str, np.ndarray]]]:
    entries = geometry.get("sides", geometry.get("tracks"))
    if not isinstance(entries, dict) or not entries:
        raise ConfigurationError("Geometry must contain a non-empty sides or tracks object.")
    nuisance = nested(config, "processing", "nuisance_correction")
    target_samples = int(geometry.get("target_samples_per_track", nuisance.get("target_samples_per_track", 101)))
    arc_samples = int(nuisance["arc_samples_per_side"])
    arc_offset = float(nuisance["arc_offset_native_pixels"])
    names: list[str] = []
    tracks: dict[str, dict[str, np.ndarray]] = {}
    for name, entry in entries.items():
        if "native_trace_col_row" in entry:
            trace = np.asarray(entry["native_trace_col_row"], dtype=int)
        elif "native_endpoints_col_row" in entry:
            trace = rasterized_trace_from_endpoints(entry["native_endpoints_col_row"])
        else:
            raise ConfigurationError(f"Geometry entry {name} lacks native_trace_col_row or native_endpoints_col_row.")
        target, plus, minus = make_track_and_arcs(trace, target_samples, arc_samples, arc_offset)
        if "geographic_endpoint_lat_lon" not in entry:
            raise ConfigurationError(f"Geometry entry {name} lacks geographic_endpoint_lat_lon required for Kz geometry.")
        names.append(str(name))
        tracks[str(name)] = {
            "target": target,
            "plus": plus,
            "minus": minus,
            "geographic_endpoint_lat_lon": np.asarray(entry["geographic_endpoint_lat_lon"], dtype=float),
        }
    lengths = {len(track["target"]) for track in tracks.values()}
    if len(lengths) != 1:
        raise ConfigurationError("Every frozen track must have the same sampled P count.")
    return names, tracks


def centred_bounds(required_low: int, required_high_exclusive: int, requested: int, full_size: int, axis_name: str) -> tuple[int, int]:
    required = required_high_exclusive - required_low
    if required <= 0:
        raise ConfigurationError(f"Invalid required {axis_name} bounds.")
    if requested < required:
        raise ConfigurationError(f"Configured {axis_name} crop of {requested} is smaller than required footprint {required}.")
    if requested > full_size:
        raise ConfigurationError(f"Configured {axis_name} crop of {requested} exceeds source extent {full_size}.")
    start = int(math.floor(0.5 * (required_low + required_high_exclusive - requested)))
    start = max(0, min(start, full_size - requested))
    end = start + requested
    if start > required_low or end < required_high_exclusive:
        raise ConfigurationError(f"Required {axis_name} Context footprint lies outside the source image.")
    return start, end


def source_bounds(tracks: dict[str, dict[str, np.ndarray]], config: dict[str, Any], shape: tuple[int, int]) -> tuple[tuple[int, int], tuple[int, int]]:
    registration = nested(config, "processing", "registration")
    context = int(registration["context_patch_pixels"])
    scoring = int(registration["scoring_patch_pixels"])
    safe_half = context // 2 + scoring // 2
    centres = np.concatenate([point for track in tracks.values() for point in (track["target"], track["plus"], track["minus"])], axis=0)
    required_rows = (int(centres[:, 0].min()) - safe_half, int(centres[:, 0].max()) + safe_half + 1)
    required_cols = (int(centres[:, 1].min()) - safe_half, int(centres[:, 1].max()) + safe_half + 1)
    crop = nested(config, "processing", "source_crop")
    rows = centred_bounds(required_rows[0], required_rows[1], int(crop["rows"]), int(shape[0]), "row")
    columns_required = required_cols
    if columns_required[0] < 0 or columns_required[1] > shape[1]:
        raise ConfigurationError("Required Context column footprint lies outside the source image.")
    if columns_required[1] - columns_required[0] > int(crop["max_columns"]):
        raise ConfigurationError("Required Context column footprint exceeds configured maximum source columns.")
    return rows, columns_required


def dataset(h5: h5py.File, path: str) -> h5py.Dataset:
    if path not in h5:
        raise ConfigurationError(f"Required HDF5 dataset {path!r} is absent.")
    return h5[path]


def frequency_masks(row_count: int, azimuth_dt: float, config: dict[str, Any]) -> tuple[np.ndarray, list[dict[str, Any]]]:
    bank = nested(config, "processing", "filter_bank")
    support = float(bank["support_hz"])
    width = float(bank["mask_width_hz"])
    bshift = float(bank["bshift_hz"])
    leap = float(bank["k_leap_hz"])
    count = int(bank["pair_count"])
    frequency_hz = fftshift(np.fft.fftfreq(row_count, d=azimuth_dt))
    support_low = -0.5 * support
    records: list[dict[str, Any]] = []
    masks: list[tuple[np.ndarray, np.ndarray]] = []
    prior_offset: tuple[float, float] | None = None
    policy = str(bank["successive_offset_overlap_policy"])
    limit = bank.get("successive_offset_overlap_fraction_limit")
    for k in range(count):
        reference_low = support_low + k * leap
        reference_high = reference_low + width
        offset_low = reference_low + bshift
        offset_high = offset_low + width
        ref_mask = (frequency_hz >= reference_low) & (frequency_hz <= reference_high)
        off_mask = (frequency_hz >= offset_low) & (frequency_hz <= offset_high)
        if not ref_mask.any() or not off_mask.any():
            raise ConfigurationError(f"Pair {k} produces an empty discrete R/O mask. Check support, width, and crop FFT length.")
        overlap = None
        overlap_fraction = None
        if prior_offset is not None:
            overlap = max(0.0, min(prior_offset[1], offset_high) - max(prior_offset[0], offset_low))
            overlap_fraction = overlap / bshift
            if policy == "enforce" and overlap_fraction > float(limit) + 1e-12:
                raise ConfigurationError(
                    f"Pair {k} violates the configured successive Offset overlap limit: {overlap_fraction:.6g} > {float(limit):.6g}."
                )
        masks.append((ref_mask.astype(np.float32), off_mask.astype(np.float32)))
        records.append({
            "pair_index": k,
            "reference_low_hz": float(reference_low),
            "reference_high_hz": float(reference_high),
            "offset_low_hz": float(offset_low),
            "offset_high_hz": float(offset_high),
            "reference_center_hz": float(0.5 * (reference_low + reference_high)),
            "offset_center_hz": float(0.5 * (offset_low + offset_high)),
            "pair_center_hz": float(0.5 * (reference_low + reference_high + bshift)),
            "reference_bins": int(ref_mask.sum()),
            "offset_bins": int(off_mask.sum()),
            "successive_offset_mask_overlap_hz": None if overlap is None else float(overlap),
            "successive_offset_mask_overlap_fraction_of_bshift": None if overlap_fraction is None else float(overlap_fraction),
        })
        prior_offset = (offset_low, offset_high)
    return np.asarray(masks, dtype=np.float32), records


def load_state(h5: h5py.File, paths: dict[str, str]) -> tuple[np.ndarray, np.ndarray, np.ndarray, float, float, np.ndarray]:
    state_times = np.array([parse_time(item) for item in np.asarray(dataset(h5, paths["state_vector_time_utc"]))])
    positions = np.column_stack((
        np.asarray(dataset(h5, paths["position_x"]), dtype=float),
        np.asarray(dataset(h5, paths["position_y"]), dtype=float),
        np.asarray(dataset(h5, paths["position_z"]), dtype=float),
    ))
    velocities = np.column_stack((
        np.asarray(dataset(h5, paths["velocity_x"]), dtype=float),
        np.asarray(dataset(h5, paths["velocity_y"]), dtype=float),
        np.asarray(dataset(h5, paths["velocity_z"]), dtype=float),
    ))
    if len(state_times) < 2 or positions.shape != velocities.shape or positions.shape[0] != len(state_times):
        raise ConfigurationError("State-vector time, position, and velocity arrays are inconsistent.")
    zero_start = parse_time(dataset(h5, paths["zero_doppler_start_utc"])[()])
    azimuth_dt = float(dataset(h5, paths["azimuth_time_interval"])[()])
    range_rate = float(dataset(h5, paths["range_sampling_rate"])[()])
    doppler_rate = np.asarray(dataset(h5, paths["doppler_rate_coefficients"]), dtype=float)
    if not (azimuth_dt > 0.0 and range_rate > 0.0 and np.all(np.isfinite(doppler_rate))):
        raise ConfigurationError("Azimuth interval, range sampling rate, or Doppler-rate coefficients are invalid.")
    return state_times, positions, velocities, zero_start, range_rate, doppler_rate


def derive_steering(
    h5: h5py.File,
    config: dict[str, Any],
    geometry: dict[str, Any],
    names: list[str],
    tracks: dict[str, dict[str, np.ndarray]],
) -> tuple[np.ndarray, np.ndarray, list[dict[str, Any]]]:
    paths = nested(config, "input", "hdf5_datasets")
    state_times, positions, velocities, zero_start, range_rate, rate_coefficients = load_state(h5, paths)
    azimuth_dt = float(dataset(h5, paths["azimuth_time_interval"])[()])
    bank = nested(config, "processing", "filter_bank")
    steering = nested(config, "steering")
    count = int(bank["pair_count"])
    support = float(bank["support_hz"])
    width = float(bank["mask_width_hz"])
    leap = float(bank["k_leap_hz"])
    bshift = float(bank["bshift_hz"])
    reference_centres = -0.5 * support + 0.5 * width + np.arange(count) * leap
    if steering["baseline_time_center"] == "reference":
        centres = reference_centres
    elif steering["baseline_time_center"] == "offset":
        centres = reference_centres + bshift
    elif steering["baseline_time_center"] == "pair_midpoint":
        centres = reference_centres + 0.5 * bshift
    else:
        raise ConfigurationError("steering.baseline_time_center must be reference, offset, or pair_midpoint.")
    target_height = float(geometry.get("projection", {}).get("height_m", steering["target_height_m"]))
    wavelength = float(steering["operational_wavelength_m"])
    all_kz: list[np.ndarray] = []
    all_bperp: list[np.ndarray] = []
    audit: list[dict[str, Any]] = []
    for name in names:
        endpoints = tracks[name]["geographic_endpoint_lat_lon"]
        if endpoints.shape != (2, 2):
            raise ConfigurationError(f"Track {name} has invalid geographic_endpoint_lat_lon.")
        latitude = float(endpoints[:, 0].mean())
        longitude = float(endpoints[:, 1].mean())
        target_ecef = ecef_from_lla(latitude, longitude, target_height)
        up = ellipsoid_up(latitude, longitude)
        midpoint_row, midpoint_col = tracks[name]["target"][len(tracks[name]["target"]) // 2]
        reference_time = zero_start + float(midpoint_row) * azimuth_dt
        sensor_reference, velocity_reference = interpolate_state(state_times, positions, velocities, reference_time)
        line_of_sight = unit(target_ecef - sensor_reference)
        aperture_direction = unit(velocity_reference - np.dot(velocity_reference, line_of_sight) * line_of_sight)
        slant_range = float(np.linalg.norm(target_ecef - sensor_reference))
        incidence = float(np.arccos(np.clip(np.dot(-line_of_sight, up), -1.0, 1.0)))
        tau = float(midpoint_col) / range_rate
        doppler_rate = float(sum(coefficient * tau ** power for power, coefficient in enumerate(rate_coefficients)))
        if abs(doppler_rate) < 1e-12:
            raise ConfigurationError(f"Track {name} has a near-zero Doppler rate at its midpoint.")
        pair_times = reference_time + centres / doppler_rate
        bperp = np.empty(count, dtype=np.float64)
        for k, pair_time in enumerate(pair_times):
            sensor, _velocity = interpolate_state(state_times, positions, velocities, float(pair_time))
            bperp[k] = np.dot(sensor - sensor_reference, aperture_direction)
        denominator = wavelength * slant_range * math.sin(incidence)
        if abs(denominator) < 1e-15:
            raise ConfigurationError(f"Track {name} gives an invalid Kz denominator.")
        kz = 4.0 * np.pi * bperp / denominator
        delta = np.diff(kz)
        recurrence = float(2.0 * np.pi / np.median(np.abs(delta))) if np.any(delta) else float("nan")
        all_kz.append(kz)
        all_bperp.append(bperp)
        audit.append({
            "track": name,
            "midpoint_row_col": [int(midpoint_row), int(midpoint_col)],
            "latitude_longitude_height_m": [latitude, longitude, target_height],
            "reference_time_utc": datetime.fromtimestamp(reference_time, tz=timezone.utc).isoformat(),
            "baseline_time_center": steering["baseline_time_center"],
            "doppler_rate_hz_per_s": doppler_rate,
            "slant_range_m": slant_range,
            "incidence_deg": float(np.rad2deg(incidence)),
            "bperp_min_max_m": [float(bperp.min()), float(bperp.max())],
            "kz_min_max_rad_per_m": [float(kz.min()), float(kz.max())],
            "recurrence_from_median_delta_kz_m": recurrence,
        })
    return np.asarray(all_kz), np.asarray(all_bperp), audit


def patch_core(image: np.ndarray, row: int, col: int, context_size: int, scoring_size: int) -> np.ndarray:
    half = context_size // 2
    context = image[row - half:row + half, col - half:col + half]
    if context.shape != (context_size, context_size):
        raise ConfigurationError("A declared Context patch leaves the reconstructed image.")
    start = (context_size - scoring_size) // 2
    core = context[start:start + scoring_size, start:start + scoring_size]
    if core.shape != (scoring_size, scoring_size):
        raise ConfigurationError("A declared scoring patch leaves the Context patch.")
    return core


def register_one(reference: np.ndarray, offset: np.ndarray, row: int, col: int, registration: dict[str, Any]) -> tuple[np.ndarray, float]:
    context = int(registration["context_patch_pixels"])
    scoring = int(registration["scoring_patch_pixels"])
    upsample = int(registration["upsample_factor"])
    ref_core = patch_core(reference, row, col, context, scoring)
    off_core = patch_core(offset, row, col, context, scoring)
    shift_row_col, error, _phase = phase_cross_correlation(
        ref_core,
        off_core,
        upsample_factor=upsample,
        normalization=registration.get("normalization"),
    )
    shift_row_col = quantize_half_away_from_zero(shift_row_col, upsample)
    # Persisted vector order is [column shift, row shift].
    return np.array([shift_row_col[1], shift_row_col[0]], dtype=np.float32), float(error)


def registration_controls(reference: np.ndarray, row: int, col: int, registration: dict[str, Any]) -> dict[str, Any]:
    """Run deterministic identity, R-copy, and imposed-shift checks on one complex patch."""
    context = int(registration["context_patch_pixels"])
    scoring = int(registration["scoring_patch_pixels"])
    upsample = int(registration["upsample_factor"])
    ref_core = patch_core(reference, row, col, context, scoring)
    identity_row_col, identity_error, _ = phase_cross_correlation(
        ref_core, ref_core, upsample_factor=upsample, normalization=registration.get("normalization")
    )
    copy_row_col, copy_error, _ = phase_cross_correlation(
        ref_core, ref_core.copy(), upsample_factor=upsample, normalization=registration.get("normalization")
    )
    imposed = np.asarray(registration["injected_shift_row_col"], dtype=float)
    if imposed.shape != (2,):
        raise ConfigurationError("registration.injected_shift_row_col must be [row, column].")
    shifted = np.fft.ifftn(fourier_shift(np.fft.fftn(ref_core), shift=imposed))
    recovered_row_col, imposed_error, _ = phase_cross_correlation(
        ref_core, shifted, upsample_factor=upsample, normalization=registration.get("normalization")
    )
    expected_correction = -imposed
    recovery_error = float(np.max(np.abs(recovered_row_col - expected_correction)))
    maximum = float(registration["max_registration_control_error_native_pixel"])
    result = {
        "patch_center_row_col": [int(row), int(col)],
        "identity_shift_row_col": np.asarray(identity_row_col, dtype=float).tolist(),
        "identity_error": float(identity_error),
        "reference_copy_shift_row_col": np.asarray(copy_row_col, dtype=float).tolist(),
        "reference_copy_error": float(copy_error),
        "imposed_moving_shift_row_col": imposed.tolist(),
        "expected_recovered_correction_row_col": expected_correction.tolist(),
        "recovered_correction_row_col": np.asarray(recovered_row_col, dtype=float).tolist(),
        "imposed_shift_registration_error": float(imposed_error),
        "imposed_shift_max_abs_recovery_error_native_pixel": recovery_error,
        "maximum_allowed_error_native_pixel": maximum,
        "passed": bool(recovery_error <= maximum),
    }
    if not result["passed"]:
        raise RuntimeError(
            "Injected-shift registration control failed: "
            f"{recovery_error:.4f} native pixel exceeds {maximum:.4f}."
        )
    return result


def geometric_median(points: np.ndarray, tolerance: float = 1e-8, maximum_iterations: int = 128) -> np.ndarray:
    estimate = np.median(np.asarray(points, dtype=float), axis=0)
    for _ in range(maximum_iterations):
        delta = points - estimate
        distances = np.linalg.norm(delta, axis=1)
        close = distances < tolerance
        if np.any(close):
            return np.asarray(points[np.flatnonzero(close)[0]], dtype=float)
        weights = 1.0 / distances
        updated = np.sum(points * weights[:, None], axis=0) / np.sum(weights)
        if np.linalg.norm(updated - estimate) < tolerance:
            return updated
        estimate = updated
    return estimate


def measurement_locations(names: list[str], tracks: dict[str, dict[str, np.ndarray]], source_row0: int, source_col0: int) -> list[tuple[int, int, int, int, int]]:
    records: list[tuple[int, int, int, int, int]] = []
    for track_index, name in enumerate(names):
        for kind_index, kind in enumerate(("target", "plus", "minus")):
            for point_index, (row, col) in enumerate(tracks[name][kind]):
                records.append((track_index, kind_index, point_index, int(row - source_row0), int(col - source_col0)))
    return records


def ensure_locations_fit(source: np.ndarray, records: list[tuple[int, int, int, int, int]], context_size: int) -> None:
    half = context_size // 2
    min_row = min(record[3] - half for record in records)
    max_row = max(record[3] + half for record in records)
    min_col = min(record[4] - half for record in records)
    max_col = max(record[4] + half for record in records)
    if min_row < 0 or max_row > source.shape[0] or min_col < 0 or max_col > source.shape[1]:
        raise ConfigurationError("At least one declared Context patch leaves the reconstructed source strip.")


def measure_vectors(
    source: np.ndarray,
    masks: np.ndarray,
    source_row0: int,
    source_col0: int,
    names: list[str],
    tracks: dict[str, dict[str, np.ndarray]],
    config: dict[str, Any],
    smoke: bool,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray, dict[str, Any] | None]:
    """Reconstruct matched R/O pairs and return Y, arcs, G_arc, q, errors, controls."""
    registration = nested(config, "processing", "registration")
    nuisance = nested(config, "processing", "nuisance_correction")
    context = int(registration["context_patch_pixels"])
    pair_count = masks.shape[0]
    target_count = len(tracks[names[0]]["target"])
    arc_count = len(tracks[names[0]]["plus"])
    records = measurement_locations(names, tracks, source_row0, source_col0)
    ensure_locations_fit(source, records, context)
    y = np.full((len(names), target_count, pair_count, 2), np.nan, dtype=np.float32)
    arcs = np.full((len(names), 2, arc_count, pair_count, 2), np.nan, dtype=np.float32)
    errors = np.full((len(names), target_count + 2 * arc_count, pair_count), np.nan, dtype=np.float32)
    spectrum = fftshift(fft(source, axis=0, workers=1), axes=0)
    del source
    indices: Iterable[int] = [pair_count // 2] if smoke else range(pair_count)
    total = 1 if smoke else pair_count
    controls: dict[str, Any] | None = None
    started = time.perf_counter()
    print(f"Reconstructing {total} matched R/O pairs and measuring {len(records)} Context supports per pair.", flush=True)
    for step, k in enumerate(indices, start=1):
        reference = ifft(ifftshift(spectrum * masks[k, 0, :, None], axes=0), axis=0, workers=1)
        offset = ifft(ifftshift(spectrum * masks[k, 1, :, None], axes=0), axis=0, workers=1)
        if controls is None:
            first = records[0]
            controls = registration_controls(reference, first[3], first[4], registration)
            controls["control_pair_index"] = int(k)
        for track_index, kind_index, point_index, row, col in records:
            vector, error = register_one(reference, offset, row, col, registration)
            if kind_index == 0:
                y[track_index, point_index, k] = vector
                errors[track_index, point_index, k] = error
            else:
                side_index = kind_index - 1
                arcs[track_index, side_index, point_index, k] = vector
                errors[track_index, target_count + side_index * arc_count + point_index, k] = error
        del reference, offset
        if step == total or step % 10 == 0:
            print(f"  pair {k:03d} ({step}/{total}) - {time.perf_counter() - started:.1f} s elapsed", flush=True)
    if smoke:
        return y, arcs, np.empty((0,), dtype=np.float32), np.empty((0,), dtype=np.float32), errors, controls

    g_arc = np.empty((len(names), pair_count, 2), dtype=np.float32)
    for track_index in range(len(names)):
        for k in range(pair_count):
            plus = geometric_median(arcs[track_index, 0, :, k])
            minus = geometric_median(arcs[track_index, 1, :, k])
            g_arc[track_index, k] = 0.5 * (plus + minus)
    q = y - g_arc[:, None, :, :]
    identity_error = float(np.nanmax(np.abs(y - (g_arc[:, None, :, :] + q))))
    if identity_error > 1e-6:
        raise RuntimeError(f"The required q = Y - G_arc identity failed ({identity_error}).")
    return y, arcs, g_arc, q, errors, controls


def modal_gate(q: np.ndarray, config: dict[str, Any]) -> tuple[dict[str, np.ndarray], dict[str, int]]:
    gates = nested(config, "gates")
    window = int(gates["window_pairs"])
    mode_min, mode_max = map(int, gates["mode_range"])
    track_count = int(gates["same_mode_contiguous_windows"])
    start_low, start_high = map(int, gates["central_track_family_start_range"])
    n_positions, k_count, components = q.shape
    if components != 2:
        raise ConfigurationError("This reference implementation expects two registered displacement components.")
    n_windows = k_count - window + 1
    modes = np.zeros((n_positions, n_windows), dtype=np.int16)
    adjusted_r2 = np.full((n_positions, n_windows), np.nan, dtype=np.float32)
    minor = np.full((n_positions, n_windows), np.nan, dtype=np.float32)
    axis_ratio = np.full((n_positions, n_windows), np.nan, dtype=np.float32)
    passes = np.zeros((n_positions, n_windows), dtype=bool)
    sample = np.arange(window, dtype=np.float64)
    n_scalar, parameter_count = 2 * window, 6
    for start in range(n_windows):
        block = q[:, start:start + window, :].astype(np.float64, copy=False)
        centered = block - block.mean(axis=1, keepdims=True)
        ss_total = np.sum(centered * centered, axis=(1, 2))
        candidates = mode_max - mode_min + 1
        candidate_score = np.full((candidates, n_positions), -np.inf)
        candidate_minor = np.zeros((candidates, n_positions))
        candidate_ratio = np.zeros((candidates, n_positions))
        for mode_offset, mode in enumerate(range(mode_min, mode_max + 1)):
            design = np.column_stack((
                np.ones(window),
                np.cos(2.0 * np.pi * mode * sample / window),
                np.sin(2.0 * np.pi * mode * sample / window),
            ))
            coefficients = np.einsum("aw,nwc->nac", np.linalg.pinv(design), block, optimize=True)
            predicted = np.einsum("wa,nac->nwc", design, coefficients, optimize=True)
            ss_residual = np.sum((block - predicted) ** 2, axis=(1, 2))
            r2 = 1.0 - ss_residual / np.maximum(ss_total, 1e-15)
            adjusted = 1.0 - (1.0 - r2) * (n_scalar - 1) / (n_scalar - parameter_count - 1)
            ellipse_map = np.transpose(coefficients[:, 1:3, :], (0, 2, 1))
            singular = np.linalg.svd(ellipse_map, compute_uv=False)
            candidate_score[mode_offset] = adjusted
            candidate_minor[mode_offset] = singular[:, 1]
            candidate_ratio[mode_offset] = singular[:, 1] / np.maximum(singular[:, 0], 1e-15)
        winner = np.argmax(candidate_score, axis=0)
        rows = np.arange(n_positions)
        modes[:, start] = winner + mode_min
        adjusted_r2[:, start] = candidate_score[winner, rows]
        minor[:, start] = candidate_minor[winner, rows]
        axis_ratio[:, start] = candidate_ratio[winner, rows]
        passes[:, start] = (
            (adjusted_r2[:, start] >= float(gates["ellipse_adjusted_r2_min"]))
            & (minor[:, start] >= float(gates["ellipse_minor_semiaxis_min_native_pixel"]))
            & (axis_ratio[:, start] >= float(gates["ellipse_axis_ratio_min"]))
        )

    family_starts = np.arange(start_low, start_high + 1, dtype=int)
    family_pass = np.zeros((n_positions, len(family_starts)), dtype=bool)
    family_mode = np.zeros((n_positions, len(family_starts)), dtype=np.int16)
    for family_index, start in enumerate(family_starts):
        candidate_mode = modes[:, start]
        same_mode = modes[:, start:start + track_count] == candidate_mode[:, None]
        family_pass[:, family_index] = np.all(passes[:, start:start + track_count] & same_mode, axis=1)
        family_mode[:, family_index] = candidate_mode
    return {
        "window_mode": modes,
        "window_adjr2": adjusted_r2,
        "window_minor": minor,
        "window_axis_ratio": axis_ratio,
        "window_pass": passes,
        "family_starts": family_starts,
        "family_pass": family_pass,
        "family_mode": family_mode,
    }, {
        "individual_window_passes": int(passes.sum()),
        "same_mode_track_families": int(family_pass.sum()),
    }


def support_gate(
    family_pass: np.ndarray,
    family_starts: np.ndarray,
    window_mode: np.ndarray,
    config: dict[str, Any],
    support_pixels: int,
) -> tuple[np.ndarray, np.ndarray]:
    """Return Track eligibility and exact-start, same-mode P-support eligibility.

    Each P position can enter Track eligibility through a different Track10 family.
    Spatial support is nevertheless evaluated at one *identical individual W start*
    and one identical winning mode across a contiguous P run.
    """
    gates = nested(config, "gates")
    track_count = int(gates["same_mode_contiguous_windows"])
    mode_min, mode_max = map(int, gates["mode_range"])
    n_positions, _n_families = family_pass.shape
    n_windows = window_mode.shape[1]
    track_eligible = np.zeros((n_positions, n_windows), dtype=bool)
    for family_index, start in enumerate(family_starts):
        positions = family_pass[:, family_index]
        if positions.any():
            track_eligible[positions, start:start + track_count] = True

    window_gate = np.zeros_like(track_eligible)
    for window_start in range(n_windows):
        for mode in range(mode_min, mode_max + 1):
            eligible = track_eligible[:, window_start] & (window_mode[:, window_start] == mode)
            begin = 0
            while begin < n_positions:
                while begin < n_positions and not eligible[begin]:
                    begin += 1
                end = begin
                while end < n_positions and eligible[end]:
                    end += 1
                if end - begin >= support_pixels:
                    window_gate[begin:end, window_start] = True
                begin = end + 1
    return track_eligible, window_gate


def depth_grid(config: dict[str, Any]) -> np.ndarray:
    grid = nested(config, "steering", "depth_grid_m")
    minimum = float(grid["minimum"])
    maximum = float(grid["maximum"])
    step = float(grid["step"])
    values = np.arange(minimum, maximum + 0.5 * step, step, dtype=np.float64)
    if not np.isclose(values[-1], maximum, atol=1e-10, rtol=0.0):
        raise ConfigurationError("Depth grid maximum is not reached exactly by the declared step.")
    return values


def conditional_focus(
    q: np.ndarray,
    kz: np.ndarray,
    window_gate: np.ndarray,
    config: dict[str, Any],
) -> tuple[np.ndarray, np.ndarray]:
    """Fit both q components to real sine/cosine steering at each accepted W start.

    The result at every (P, z) is the maximum adjusted R2 across accepted starts.
    ``winning_start`` explicitly records which W start provided that score.
    """
    window = int(nested(config, "gates", "window_pairs"))
    z_values = depth_grid(config)
    n_positions = q.shape[0]
    scores = np.full((n_positions, len(z_values)), np.nan, dtype=np.float32)
    winning_start = np.full((n_positions, len(z_values)), -1, dtype=np.int16)
    n_scalar, parameter_count = 2 * window, 4
    active_starts = np.flatnonzero(window_gate.any(axis=0))
    for start in active_starts:
        positions = np.flatnonzero(window_gate[:, start])
        block = q[:, start:start + window, :].astype(np.float64, copy=False)
        total_energy = np.sum(block * block, axis=(1, 2))
        centered = block - block.mean(axis=1, keepdims=True)
        total_variance = np.sum(centered * centered, axis=(1, 2))
        phase = np.outer(z_values, kz[start:start + window])
        cosine = np.cos(phase)
        sine = np.sin(phase)
        g00 = np.sum(cosine * cosine, axis=1)
        g01 = np.sum(cosine * sine, axis=1)
        g11 = np.sum(sine * sine, axis=1)
        determinant = np.maximum(g00 * g11 - g01 * g01, 1e-15)
        cross0 = np.einsum("zw,nwc->znc", cosine, block, optimize=True)
        cross1 = np.einsum("zw,nwc->znc", sine, block, optimize=True)
        coefficient0 = (g11[:, None, None] * cross0 - g01[:, None, None] * cross1) / determinant[:, None, None]
        coefficient1 = (-g01[:, None, None] * cross0 + g00[:, None, None] * cross1) / determinant[:, None, None]
        fitted_energy = np.sum(coefficient0 * cross0 + coefficient1 * cross1, axis=2)
        residual = total_energy[None, :] - fitted_energy
        r2 = 1.0 - residual / np.maximum(total_variance[None, :], 1e-15)
        adjusted = 1.0 - (1.0 - r2) * (n_scalar - 1) / (n_scalar - parameter_count - 1)
        candidate = adjusted[:, positions].T.astype(np.float32)
        existing = scores[positions]
        replace = np.isnan(existing) | (candidate > existing)
        scores[positions] = np.where(replace, candidate, existing)
        old_starts = winning_start[positions]
        winning_start[positions] = np.where(replace, int(start), old_starts)
    return scores, winning_start


def endpoint_label(name: str, geometry: dict[str, Any]) -> str:
    entries = geometry.get("sides", geometry.get("tracks", {}))
    entry = entries[name]
    start = entry.get("P0_corner", entry.get("P0_label", "P0"))
    end = entry.get("P_last_corner", entry.get("P_last_label", "P last"))
    return f"{start} to {end}"


def render_tomograms(
    names: list[str],
    geometry: dict[str, Any],
    focus_by_support: dict[int, np.ndarray],
    z_values: np.ndarray,
    output_path: Path,
) -> None:
    supports = list(focus_by_support)
    p_count = next(iter(focus_by_support.values())).shape[1]
    figure, axes = plt.subplots(
        len(supports), len(names),
        figsize=(5.2 * len(names), 4.5 * len(supports) + 0.5),
        constrained_layout=True,
        facecolor="#101010",
        squeeze=False,
    )
    cmap = plt.get_cmap("magma").copy()
    cmap.set_bad("black")
    images = []
    step = float(z_values[1] - z_values[0]) if len(z_values) > 1 else 1.0
    for row, support in enumerate(supports):
        values = focus_by_support[support]
        for column, name in enumerate(names):
            axis = axes[row, column]
            image = axis.imshow(
                np.clip(values[column].T, 0.0, 1.0),
                origin="upper",
                aspect="auto",
                cmap=cmap,
                vmin=0.0,
                vmax=1.0,
                interpolation="nearest",
                extent=(-0.5, p_count - 0.5, float(z_values[-1] + 0.5 * step), float(z_values[0] - 0.5 * step)),
            )
            images.append(image)
            axis.set_facecolor("black")
            axis.set_title(f"{name} ({endpoint_label(name, geometry)})", color="white", fontsize=11)
            axis.xaxis.tick_top()
            axis.xaxis.set_label_position("top")
            axis.set_xlabel("P", color="white")
            if column == 0:
                axis.set_ylabel(f"Nominal depth (m)\nP={support}", color="white")
            axis.tick_params(colors="white", labelsize=9)
            for spine in axis.spines.values():
                spine.set_color("white")
    figure.suptitle(
        "Biondi Protocol v1.8 conditional depth focus\n"
        "q = Y - G_arc; W-window sine/cosine least squares; display clipped only at 0 through 1",
        color="white", fontsize=14,
    )
    colourbar = figure.colorbar(images[-1], ax=axes, shrink=0.78, pad=0.02)
    colourbar.set_label("Conditional adjusted R2", color="white")
    colourbar.ax.tick_params(colors="white")
    figure.savefig(output_path, dpi=220, facecolor="#101010")
    plt.close(figure)


def dependency_versions() -> dict[str, str]:
    return {
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "numpy": np.__version__,
        "scipy": scipy.__version__,
        "h5py": h5py.__version__,
        "scikit_image": skimage.__version__,
        "matplotlib": matplotlib.__version__,
    }


def output_directory(config: dict[str, Any], config_path: Path, supplied: str | None) -> Path:
    value = supplied if supplied is not None else nested(config, "output", "directory")
    return resolve_path(value, config_path.parent)


def make_output_directory(path: Path) -> None:
    if path.exists():
        raise FileExistsError(f"Refusing to overwrite existing output directory: {path}")
    path.mkdir(parents=True, exist_ok=False)


def audit_arrays(
    names: list[str],
    tracks: dict[str, dict[str, np.ndarray]],
    masks: np.ndarray,
    kz: np.ndarray,
    bperp: np.ndarray,
    y: np.ndarray,
    arcs: np.ndarray,
    g_arc: np.ndarray,
    q: np.ndarray,
    errors: np.ndarray,
    modal: list[dict[str, np.ndarray]],
    track_eligible: np.ndarray,
    gates_by_support: dict[int, np.ndarray],
    focus_by_support: dict[int, np.ndarray],
    winner_by_support: dict[int, np.ndarray],
    z_values: np.ndarray,
) -> dict[str, np.ndarray]:
    arrays: dict[str, np.ndarray] = {
        "filter_masks": masks,
        "kz_rad_per_m": kz,
        "bperp_m": bperp,
        "Y": y,
        "arc_vectors": arcs,
        "G_arc": g_arc,
        "q": q,
        "registration_error": errors,
        "track10_eligible": track_eligible,
        "z_m": z_values,
    }
    for index, name in enumerate(names):
        slug = name.lower().replace(" ", "_")
        arrays[f"{slug}_target_row_col"] = tracks[name]["target"]
        arrays[f"{slug}_plus_arc_row_col"] = tracks[name]["plus"]
        arrays[f"{slug}_minus_arc_row_col"] = tracks[name]["minus"]
        for key in ("window_mode", "window_adjr2", "window_minor", "window_axis_ratio", "window_pass", "family_mode", "family_pass", "family_starts"):
            arrays[f"{slug}_{key}"] = modal[index][key]
    for support, values in gates_by_support.items():
        arrays[f"p{support}_window_gate"] = values
        arrays[f"focus_p{support}"] = focus_by_support[support]
        arrays[f"winning_start_p{support}"] = winner_by_support[support]
    return arrays


def load_source_and_preflight(
    config: dict[str, Any],
    config_path: Path,
) -> tuple[Any, ...]:
    """Read the declared cropped complex source, filter bank, and Kz geometry."""
    source_path = resolve_path(nested(config, "input", "hdf5_path"), config_path.parent)
    geometry_path = resolve_path(nested(config, "input", "geometry_path"), config_path.parent)
    if not source_path.is_file():
        raise FileNotFoundError(f"SLC HDF5 file not found: {source_path}")
    if not geometry_path.is_file():
        raise FileNotFoundError(f"Frozen geometry JSON not found: {geometry_path}")
    geometry = read_json(geometry_path)
    paths = nested(config, "input", "hdf5_datasets")
    with h5py.File(source_path, "r") as h5:
        real = dataset(h5, paths["real"])
        imaginary = dataset(h5, paths["imaginary"])
        if real.shape != imaginary.shape or len(real.shape) != 2:
            raise ConfigurationError("The declared real and imaginary SLC datasets must be equal-shape two-dimensional arrays.")
        shape = tuple(map(int, real.shape))
        names, tracks = geometry_tracks(geometry, config)
        row_bounds, col_bounds = source_bounds(tracks, config, shape)
        source = (
            real[row_bounds[0]:row_bounds[1], col_bounds[0]:col_bounds[1]].astype(np.float32)
            + 1j * imaginary[row_bounds[0]:row_bounds[1], col_bounds[0]:col_bounds[1]].astype(np.float32)
        ).astype(np.complex64, copy=False)
        azimuth_dt = float(dataset(h5, paths["azimuth_time_interval"])[()])
        masks, records = frequency_masks(source.shape[0], azimuth_dt, config)
        kz, bperp, steering_audit = derive_steering(h5, config, geometry, names, tracks)
    return source_path, geometry_path, geometry, names, tracks, row_bounds, col_bounds, source, masks, records, kz, bperp, steering_audit


def run_smoke(config: dict[str, Any], config_path: Path, output_dir: Path) -> None:
    make_output_directory(output_dir)
    (
        source_path, geometry_path, geometry, names, tracks, row_bounds, col_bounds,
        source, masks, records, kz, bperp, steering_audit,
    ) = load_source_and_preflight(config, config_path)
    y, arcs, _g_arc, _q, errors, controls = measure_vectors(
        source, masks, row_bounds[0], col_bounds[0], names, tracks, config, smoke=True
    )
    middle = masks.shape[0] // 2
    observed = y[:, :, middle, :]
    np.savez_compressed(
        output_dir / "smoke_audit.npz",
        Y_middle_pair=observed,
        registration_error_middle_pair=errors[:, :, middle],
        filter_masks=masks[[middle]],
        kz_rad_per_m=kz,
        bperp_m=bperp,
    )
    manifest = {
        "title": "Biondi Protocol v1.8 smoke test",
        "protocol_version": PACKAGE_VERSION,
        "mode": "one middle R/O pair only; no modal or depth inversion",
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "source_hdf5": str(source_path),
        "source_sha256": sha256_file(source_path),
        "geometry_json": str(geometry_path),
        "geometry_sha256": sha256_file(geometry_path),
        "config_sha256": sha256_json(config),
        "source_strip": {"rows_exclusive": list(row_bounds), "columns_exclusive": list(col_bounds)},
        "middle_pair_index": int(middle),
        "middle_pair_record": records[middle],
        "registration_controls": controls,
        "steering_audit": steering_audit,
        "dependency_versions": dependency_versions(),
        "output_arrays": "smoke_audit.npz",
        "geometry_title": geometry.get("title"),
    }
    write_json(output_dir / "manifest.json", manifest)
    print(output_dir, flush=True)


def run_full(config: dict[str, Any], config_path: Path, output_dir: Path) -> None:
    make_output_directory(output_dir)
    (
        source_path, geometry_path, geometry, names, tracks, row_bounds, col_bounds,
        source, masks, records, kz, bperp, steering_audit,
    ) = load_source_and_preflight(config, config_path)
    y, arcs, g_arc, q, errors, controls = measure_vectors(
        source, masks, row_bounds[0], col_bounds[0], names, tracks, config, smoke=False
    )
    supports = [int(value) for value in nested(config, "gates", "pixel_support_variants")]
    modal_by_track: list[dict[str, np.ndarray]] = []
    track_eligible_by_track: list[np.ndarray] = []
    gates_by_support: dict[int, list[np.ndarray]] = {support: [] for support in supports}
    focus_by_support: dict[int, list[np.ndarray]] = {support: [] for support in supports}
    winner_by_support: dict[int, list[np.ndarray]] = {support: [] for support in supports}
    side_counts: dict[str, dict[str, int]] = {}
    for track_index, name in enumerate(names):
        print(f"Applying modal, Track10, P-support, and conditional focus gates: {name}", flush=True)
        modal, counts = modal_gate(q[track_index], config)
        modal_by_track.append(modal)
        side_counts[name] = dict(counts)
        reference_track_eligible: np.ndarray | None = None
        for support in supports:
            track_eligible, window_gate = support_gate(
                modal["family_pass"], modal["family_starts"], modal["window_mode"], config, support
            )
            if reference_track_eligible is None:
                reference_track_eligible = track_eligible
                track_eligible_by_track.append(track_eligible)
            elif not np.array_equal(reference_track_eligible, track_eligible):
                raise RuntimeError("Track eligibility changed across P-support variants.")
            score, winner = conditional_focus(q[track_index], kz[track_index], window_gate, config)
            gates_by_support[support].append(window_gate)
            focus_by_support[support].append(score)
            winner_by_support[support].append(winner)
            side_counts[name][f"p{support}_accepted_w50_cells"] = int(window_gate.sum())
            side_counts[name][f"p{support}_supported_positions"] = int(np.isfinite(score).any(axis=1).sum())

    focus_arrays = {support: np.asarray(values) for support, values in focus_by_support.items()}
    winner_arrays = {support: np.asarray(values) for support, values in winner_by_support.items()}
    gate_arrays = {support: np.asarray(values) for support, values in gates_by_support.items()}
    z_values = depth_grid(config)
    arrays = audit_arrays(
        names, tracks, masks, kz, bperp, y, arcs, g_arc, q, errors, modal_by_track,
        np.asarray(track_eligible_by_track), gate_arrays, focus_arrays, winner_arrays, z_values,
    )
    array_name = "biondi_v1_8_audit.npz"
    np.savez_compressed(output_dir / array_name, **arrays)
    figure_name = "conditional_depth_tomograms.png"
    render_tomograms(names, geometry, focus_arrays, z_values, output_dir / figure_name)
    resolved_config = dict(config)
    resolved_config["input"] = dict(config["input"])
    resolved_config["input"]["hdf5_path"] = str(source_path)
    resolved_config["input"]["geometry_path"] = str(geometry_path)
    write_json(output_dir / "resolved_config.json", resolved_config)
    manifest = {
        "title": "Biondi Protocol Version 1.8 full conditional-depth run",
        "protocol_version": PACKAGE_VERSION,
        "profile_name": config.get("profile_name"),
        "profile_status": config.get("status"),
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "source_hdf5": str(source_path),
        "source_sha256": sha256_file(source_path),
        "vector_array_shape": list(map(int, y.shape)),
        "geometry_json": str(geometry_path),
        "geometry_sha256": sha256_file(geometry_path),
        "geometry_title": geometry.get("title"),
        "config_sha256": sha256_json(config),
        "coordinate_convention": nested(config, "input", "coordinate_convention"),
        "source_strip": {
            "rows_exclusive": list(row_bounds),
            "columns_exclusive": list(col_bounds),
            "fft_axis": nested(config, "processing", "fft", "doppler_axis"),
            "fft_mode": nested(config, "processing", "fft", "mode"),
        },
        "filter_bank": {
            **nested(config, "processing", "filter_bank"),
            "pair_records": records,
        },
        "registration": nested(config, "processing", "registration"),
        "registration_controls": controls,
        "nuisance_correction": {
            **nested(config, "processing", "nuisance_correction"),
            "formula": "q = Y - G_arc",
            "G_arc": "mean of the plus and minus geometric-median nuisance vectors",
        },
        "gates": nested(config, "gates"),
        "depth_focus": {
            **nested(config, "steering"),
            "formula": "For each accepted W start and z, q[k,c] = a[c] cos(Kz[k] z) + b[c] sin(Kz[k] z) + residual; adjusted R2 is aggregated by maximum over accepted starts.",
            "display": nested(config, "steering", "display"),
            "z_values_saved": True,
            "winning_start_saved": True,
        },
        "steering_audit": steering_audit,
        "track_counts": side_counts,
        "dependency_versions": dependency_versions(),
        "output_arrays": array_name,
        "output_figure": figure_name,
        "resolved_config": "resolved_config.json",
        "interpretation_constraint": "Scores are conditional image-model fit metrics. They are not detection probabilities, independently established physical motion, cavity identity, penetration, or absolute depth.",
    }
    write_json(output_dir / "manifest.json", manifest)
    print(output_dir, flush=True)


def run_self_test() -> None:
    """Fast, data-free checks of the W-window gate hierarchy and depth fitting."""
    config: dict[str, Any] = {
        "protocol_version": PACKAGE_VERSION,
        "input": {"hdf5_datasets": {key: key for key in (
            "real", "imaginary", "azimuth_time_interval", "zero_doppler_start_utc", "state_vector_time_utc",
            "position_x", "position_y", "position_z", "velocity_x", "velocity_y", "velocity_z",
            "range_sampling_rate", "doppler_rate_coefficients",
        )}},
        "processing": {
            "source_crop": {"rows": 100, "max_columns": 100},
            "filter_bank": {"support_hz": 10, "mask_width_hz": 5, "bshift_hz": 1, "k_leap_hz": 1, "pair_count": 32,
                            "successive_offset_overlap_policy": "record_only", "successive_offset_overlap_fraction_limit": None},
            "registration": {"context_patch_pixels": 16, "scoring_patch_pixels": 8, "upsample_factor": 20,
                             "injected_shift_row_col": [0.2, -0.15], "max_registration_control_error_native_pixel": 0.1},
            "nuisance_correction": {"arc_samples_per_side": 2, "arc_offset_native_pixels": 1},
        },
        "gates": {
            "window_pairs": 10, "mode_range": [1, 3], "ellipse_adjusted_r2_min": 0.25,
            "ellipse_minor_semiaxis_min_native_pixel": 0.005, "ellipse_axis_ratio_min": 0.1,
            "same_mode_contiguous_windows": 3, "central_track_family_start_range": [3, 14],
            "pixel_support_variants": [4],
        },
        "steering": {
            "target_height_m": 1, "operational_wavelength_m": 1, "baseline_time_center": "pair_midpoint",
            "depth_grid_m": {"minimum": 0, "maximum": 8, "step": 0.1}, "display": "test",
        },
        "output": {"directory": "unused"},
    }
    validate_config(config)
    positions, pairs, mode = 5, 32, 2
    phase = 2.0 * np.pi * mode * np.arange(pairs) / 10.0
    q_modal = np.empty((positions, pairs, 2), dtype=np.float64)
    q_modal[:, :, 0] = np.cos(phase)[None, :]
    q_modal[:, :, 1] = np.sin(phase)[None, :]
    metrics, counts = modal_gate(q_modal, config)
    track_eligible, pixel_gate = support_gate(metrics["family_pass"], metrics["family_starts"], metrics["window_mode"], config, 4)
    if not pixel_gate.any() or not track_eligible.any():
        raise AssertionError("Self-test modal / Track10 / P4 hierarchy did not retain the synthetic family.")

    # A same-mode Track10 family at disjoint starts cannot supply exact-start P support.
    disjoint_families = np.zeros((2, 2), dtype=bool)
    disjoint_families[0, 0] = True
    disjoint_families[1, 1] = True
    disjoint_modes = np.full((2, 12), 2, dtype=np.int16)
    _eligibility, disjoint_gate = support_gate(
        disjoint_families, np.array([1, 7]), disjoint_modes, config, 2
    )
    if disjoint_gate.any():
        raise AssertionError("Self-test exact-start spatial support accepted disjoint Track10 starts.")

    z_true = 3.0
    kz = np.linspace(-1.0, 1.0, pairs)
    q_depth = np.empty((positions, pairs, 2), dtype=np.float64)
    q_depth[:, :, 0] = np.cos(kz * z_true)[None, :]
    q_depth[:, :, 1] = np.sin(kz * z_true)[None, :]
    depth_gate = np.zeros((positions, pairs - 10 + 1), dtype=bool)
    depth_gate[:, 5] = True
    score, winner = conditional_focus(q_depth, kz, depth_gate, config)
    z_values = depth_grid(config)
    peak = float(z_values[np.nanargmax(score[0])])
    if abs(peak - z_true) > 0.11 or not np.all(winner[:, np.nanargmax(score[0])] == 5):
        raise AssertionError("Self-test conditional depth fit did not retain its exact W start at the known nominal depth.")
    print(json.dumps({
        "protocol_version": PACKAGE_VERSION,
        "result": "passed",
        "modal_counts": counts,
        "depth_peak_m": peak,
        "winning_start": 5,
        "tested_rules": ["modal ellipse gate", "same-mode Track10", "exact-start P support", "two-component depth least squares"],
    }, indent=2))


def main() -> None:
    parser = argparse.ArgumentParser(description="Standalone Biondi Protocol v1.8 pipeline.")
    parser.add_argument("--config", type=Path, help="Run-profile JSON. Required unless --self-test is used.")
    parser.add_argument("--output-dir", help="Override the declared output directory without modifying the profile.")
    parser.add_argument("--smoke", action="store_true", help="Reconstruct and register the middle R/O pair only; no gates or depth focus.")
    parser.add_argument("--validate-config", action="store_true", help="Validate the profile and exit without opening the SLC.")
    parser.add_argument("--self-test", action="store_true", help="Run fast data-free gate and depth-fit checks.")
    args = parser.parse_args()
    if args.self_test:
        if args.config is not None or args.smoke or args.output_dir is not None or args.validate_config:
            parser.error("--self-test is used alone.")
        run_self_test()
        return
    if args.config is None:
        parser.error("--config is required unless --self-test is used.")
    config_path = args.config.expanduser().resolve()
    if not config_path.is_file():
        parser.error(f"Configuration file not found: {config_path}")
    config = read_json(config_path)
    validate_config(config)
    if args.validate_config:
        print(json.dumps({"protocol_version": PACKAGE_VERSION, "profile": config.get("profile_name"), "result": "valid"}, indent=2))
        return
    output_dir = output_directory(config, config_path, args.output_dir)
    if args.smoke:
        run_smoke(config, config_path, output_dir)
    else:
        run_full(config, config_path, output_dir)


if __name__ == "__main__":
    main()
