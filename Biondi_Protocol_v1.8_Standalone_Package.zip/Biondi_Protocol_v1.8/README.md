# Biondi Protocol Version 1.8

Version 1.8 is a standalone, audit-first reference package for single-acquisition subaperture tomography. It contains the complete executable pipeline rather than relying on project-local helper modules or undocumented gate logic.

The supplied ICEYE X13 Khafre profile reproduces the frozen operational choice set: a 317-pair broad-overlap bank, W=50, modes 1 through 10, ellipse thresholds, Track10, central-K confinement, and exact-start P=4/P=5 support. Those values are a declared profile, not universal physical defaults.

## Package contents

| File or directory | Purpose |
|---|---|
| `biondi_tomography_v1_8.py` | The complete runnable Python pipeline. It has no project-local imports. |
| `profiles/iceye_x13_khafre_w50.json` | Frozen ICEYE X13 / Khafre W50 Track10 profile. |
| `templates/geometry_template.json` | Required native-SLC geometry data format. |
| `Generic_Biondi_Subaperture_Tomography_Protocol_v1.8.md` | Formal specification of the processing, gates, outputs, and interpretation boundary. |
| `Generic_Biondi_Subaperture_Tomography_Protocol_v1.8.docx` | Same protocol in Word form. |
| `requirements.txt` | Runtime dependencies. |
| `data/` | Empty landing directory for the two supplied Khafre data files. |
| `tests/` | Data-free self-test plus a small synthetic ICEYE-style integration test. |

## Run it from a clean copy

Create a Python environment, install the declared dependencies, then confirm the executable without any data file:

```bash
python -m venv .venv
source .venv/bin/activate                 # Windows: .venv\Scripts\activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python biondi_tomography_v1_8.py --self-test
```

The self-test verifies the modal ellipse gate, same-mode Track10 eligibility, exact-W-start pixel support, and two-component conditional-depth least squares.

Put the data files named by a profile where its relative paths expect them. The supplied Khafre profile expects:

```text
data/
  ICEYE_X13_SLC_SLED_868226_20220715T235744.h5
  ICEYE_X13_Khafre_Petrie_Dash_FourSides_H70p5m_FrozenGeometry.json
```

First test the full HDF5 intake, state vectors, pair reconstruction, and registration without doing a full run:

```bash
python biondi_tomography_v1_8.py \
  --config profiles/iceye_x13_khafre_w50.json \
  --smoke \
  --output-dir outputs/khafre_smoke
```

Then run the complete pipeline:

```bash
python biondi_tomography_v1_8.py \
  --config profiles/iceye_x13_khafre_w50.json \
  --output-dir outputs/khafre_full
```

The executable refuses to overwrite an existing output directory. Make a new output directory for each run.

## What the executable does

1. Hashes the declared SLC and geometry files and records their identities.
2. Reads the complex SLC, applies the declared axis-0 Doppler R/O masks, and inverse-transforms each matched pair.
3. Runs complex phase cross-correlation only between the same R/O pair at every target and nuisance-arc location. It uses Context128 with a central 32x32 scoring patch in the Khafre profile.
4. Produces raw pairwise vectors \(Y_k\), two nuisance-arc medians, \(G_{arc}\), and the canonical residual \(q_k=Y_k-G_{arc,k}\).
5. Fits modal ellipses to every sliding W window, applies the declared W50 / m=1-10 / ellipse / Track10 / central-family gates, and then applies exact-start contiguous P support.
6. Builds acquisition-specific \(K_z\) from state vectors and evaluates the real sine/cosine steering basis at every declared nominal depth for every accepted W start.
7. Saves the maximum adjusted \(R^2\) at each \((P,z)\), plus the exact W start that won that cell.

## Frozen Khafre gate stack

| Stage | Frozen profile rule |
|---|---|
| Modal candidate | W=50; choose one winning mode from m=1 through m=10 for each W start. |
| Per-window ellipse gates | Modal adjusted \(R^2 \ge 0.25\); minor semiaxis \(\ge 0.005\) native pixel; \(b/a \ge 0.10\). |
| Track10 | Ten one-start-shifted W50 windows must all pass and have the same winning mode. |
| Central K confinement | A Track10 family start must be 50 through 191, keeping its full 59-pair family inside K50 through K249. |
| P support | At one identical individual W start and mode, P=4 or P=5 contiguous positions must be independently Track10-eligible. A position can enter via a different Track10 family, but a nonshared W start never supplies spatial support. |
| Depth focus | At every accepted start and depth, fit both q components to \(a_c\cos(K_{z,k}z)+b_c\sin(K_{z,k}z)\). The displayed value is the maximum adjusted \(R^2\) over accepted starts. |

P=4 means four contiguous sampled P positions total. It does not mean four pixels on each flank of a target position.

## Pair overlap policy

Version 1.8 records realized successive Offset-mask overlap in every pair record but does not use the former 5 percent Offset-edge rule as a hard acceptance gate. The supplied bank has B=404.053866 Hz and K leap=101.031907 Hz. This decision is explicit in the profile and manifest rather than implicit in the code.

## Required data contract

The reference profile uses an ICEYE-style HDF5 layout with the following datasets:

- `s_i`, `s_q`: two-dimensional real and imaginary SLC arrays with [azimuth/Doppler row, range column] order;
- azimuth timing, zero-Doppler start time, range sampling rate, and Doppler-rate coefficients;
- state-vector times, positions, and velocities.

The JSON profile maps every dataset path, so a compatible HDF5 product can use different names without changing the Python source. The frozen geometry JSON supplies full native traces in [column, row] order and geographic endpoints for the Kz calculation.

## Audit outputs

Every full run writes:

- `manifest.json`: input hashes, resolved profile, filter bank, registration control result, gate stack, Kz audit, and output inventory;
- `resolved_config.json`: the exact profile with absolute input paths;
- `biondi_v1_8_audit.npz`: masks, Y, arcs, G_arc, q, registration errors, modal metrics, Track10 eligibility, exact-start P gates, depth scores, and winning W-start identities;
- `conditional_depth_tomograms.png`: display-only 0 to 1 clipped conditional adjusted-R2 panels.

Black cells are unsupported. A black display cell does not distinguish an unsupported NaN from an accepted negative adjusted score after display clipping; the NPZ audit preserves that distinction.

## Interpretation boundary

The depth axis is a nominal steering-model coordinate. Registration vectors and conditional adjusted-R2 scores are image-processing observables and model-fit metrics. They do not by themselves establish physical motion, void identity, penetration, or absolute depth. The audit saves recurrence information and the exact winning start so periodic depth companions and window provenance remain inspectable.

## Test the whole chain with synthetic data

From the package root:

```bash
python tests/create_synthetic_iceye_data.py
python biondi_tomography_v1_8.py --config tests/synthetic_profile.json
```

This creates small synthetic HDF5 and geometry data, runs the whole executable chain, and writes a disposable `tests/synthetic_output/` audit directory. The synthetic scene is only an integration test; it is not a validation of physical interpretation.
