"""Build the formal Biondi Protocol Version 1.8 Word document."""

from __future__ import annotations

from pathlib import Path

from docx import Document
from docx.enum.section import WD_SECTION_START
from docx.enum.table import WD_ALIGN_VERTICAL
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor


ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "Generic_Biondi_Subaperture_Tomography_Protocol_v1.8.docx"


def set_cell_shading(cell, fill: str) -> None:
    properties = cell._tc.get_or_add_tcPr()
    shading = OxmlElement("w:shd")
    shading.set(qn("w:fill"), fill)
    properties.append(shading)


def set_cell_borders(cell) -> None:
    properties = cell._tc.get_or_add_tcPr()
    borders = OxmlElement("w:tcBorders")
    for edge in ("top", "left", "bottom", "right", "insideH", "insideV"):
        element = OxmlElement(f"w:{edge}")
        element.set(qn("w:val"), "single")
        element.set(qn("w:sz"), "4")
        element.set(qn("w:space"), "0")
        element.set(qn("w:color"), "D9D9D9")
        borders.append(element)
    properties.append(borders)


def set_cell_margins(cell, top: int = 90, start: int = 110, bottom: int = 90, end: int = 110) -> None:
    properties = cell._tc.get_or_add_tcPr()
    margins = OxmlElement("w:tcMar")
    for side, value in (("top", top), ("start", start), ("bottom", bottom), ("end", end)):
        element = OxmlElement(f"w:{side}")
        element.set(qn("w:w"), str(value))
        element.set(qn("w:type"), "dxa")
        margins.append(element)
    properties.append(margins)


def set_run_font(run, name: str = "Aptos", size: float = 10.8, bold: bool = False, color: str = "000000") -> None:
    run.font.name = name
    run._element.rPr.rFonts.set(qn("w:ascii"), name)
    run._element.rPr.rFonts.set(qn("w:hAnsi"), name)
    run.font.size = Pt(size)
    run.font.bold = bold
    run.font.color.rgb = RGBColor.from_string(color)


def add_paragraph(doc: Document, text: str = "", style: str | None = None, after: float = 6.0) -> None:
    paragraph = doc.add_paragraph(style=style)
    paragraph.paragraph_format.space_after = Pt(after)
    paragraph.paragraph_format.line_spacing = 1.12
    run = paragraph.add_run(text)
    set_run_font(run)


def add_bullet(doc: Document, text: str) -> None:
    paragraph = doc.add_paragraph(style="List Bullet")
    paragraph.paragraph_format.space_after = Pt(4)
    paragraph.paragraph_format.line_spacing = 1.08
    set_run_font(paragraph.add_run(text), size=10.5)


def add_equation(doc: Document, text: str) -> None:
    """Add a portable display equation.

    LibreOffice's PDF conversion does not faithfully lay out raw Office Math
    XML with mixed Unicode subscripts.  A centered Cambria Math run preserves
    the notation in both Word and the rendered verification copy.
    """
    paragraph = doc.add_paragraph()
    paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
    paragraph.paragraph_format.space_before = Pt(2)
    paragraph.paragraph_format.space_after = Pt(8)
    paragraph.paragraph_format.keep_with_next = True
    run = paragraph.add_run(text)
    set_run_font(run, name="Cambria Math", size=11.2)
    run.font.italic = True


def add_table(doc: Document, headings: list[str], rows: list[list[str]], widths: list[float]) -> None:
    table = doc.add_table(rows=1, cols=len(headings))
    table.autofit = False
    table.style = "Table Grid"
    header = table.rows[0].cells
    for index, title in enumerate(headings):
        header[index].width = Inches(widths[index])
        set_cell_shading(header[index], "1F4E78")
        set_cell_borders(header[index])
        set_cell_margins(header[index])
        header[index].vertical_alignment = WD_ALIGN_VERTICAL.CENTER
        paragraph = header[index].paragraphs[0]
        paragraph.paragraph_format.space_after = Pt(0)
        set_run_font(paragraph.add_run(title), size=10.2, bold=True, color="FFFFFF")
    for row_index, values in enumerate(rows):
        cells = table.add_row().cells
        for index, value in enumerate(values):
            cells[index].width = Inches(widths[index])
            set_cell_borders(cells[index])
            set_cell_margins(cells[index])
            cells[index].vertical_alignment = WD_ALIGN_VERTICAL.CENTER
            if row_index % 2:
                set_cell_shading(cells[index], "F3F7FA")
            paragraph = cells[index].paragraphs[0]
            paragraph.paragraph_format.space_after = Pt(0)
            paragraph.paragraph_format.line_spacing = 1.05
            set_run_font(paragraph.add_run(value), size=9.7)
    doc.add_paragraph().paragraph_format.space_after = Pt(2)


def add_heading(doc: Document, text: str, level: int = 1) -> None:
    paragraph = doc.add_paragraph(style=f"Heading {level}")
    paragraph.paragraph_format.space_before = Pt(12 if level == 1 else 8)
    paragraph.paragraph_format.space_after = Pt(5)
    run = paragraph.add_run(text)
    set_run_font(run, size=15 if level == 1 else 12, bold=True)


def build() -> None:
    doc = Document()
    section = doc.sections[0]
    section.top_margin = Inches(0.72)
    section.bottom_margin = Inches(0.72)
    section.left_margin = Inches(0.78)
    section.right_margin = Inches(0.78)
    styles = doc.styles
    styles["Normal"].font.name = "Aptos"
    styles["Normal"]._element.rPr.rFonts.set(qn("w:ascii"), "Aptos")
    styles["Normal"]._element.rPr.rFonts.set(qn("w:hAnsi"), "Aptos")
    styles["Normal"].font.size = Pt(10.8)

    title = doc.add_paragraph(style="Title")
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    title.paragraph_format.space_after = Pt(5)
    set_run_font(title.add_run("Biondi Subaperture Tomography Protocol"), size=23, bold=True)
    subtitle = doc.add_paragraph()
    subtitle.alignment = WD_ALIGN_PARAGRAPH.CENTER
    subtitle.paragraph_format.space_after = Pt(14)
    set_run_font(subtitle.add_run("Version 1.8  |  28 September 2026"), size=12, bold=True)
    intro = doc.add_paragraph()
    intro.paragraph_format.space_after = Pt(8)
    intro.paragraph_format.line_spacing = 1.15
    set_run_font(intro.add_run(
        "Version 1.8 is the executable, audit-first form of the generic protocol. It carries the complete chain from a declared complex SLC and frozen native geometry to same-pair registrations, explicit W-window eligibility, and conditional nominal-depth focus. Every run-setting that can change a result is declared in JSON and saved in the manifest."
    ), size=11.2)
    add_paragraph(doc,
        "The protocol produces image-processing observables and conditional model-fit scores. It does not by itself establish physical motion, cavity identity, penetration, or absolute depth.",
        after=12)

    add_heading(doc, "1 Package contract")
    add_paragraph(doc, "A complete Version 1.8 release contains one Python executable with no project-local imports, a runtime dependency list, a run-profile JSON, a geometry-data template, a formal protocol, and data-free plus synthetic integration tests.")
    add_bullet(doc, "The profile maps every required HDF5 dataset, declares native coordinate order, and names the frozen geometry file.")
    add_bullet(doc, "The executable refuses to overwrite an existing output directory and writes input hashes, resolved configuration, and numerical audit arrays before interpretation.")
    add_bullet(doc, "The reference ICEYE X13 Khafre profile is an explicit operational profile, not a universal physical default.")

    add_heading(doc, "2 Input and pair-bank contract")
    add_paragraph(doc, "The complex SLC provides real and imaginary arrays, azimuth timing, zero-Doppler epoch, range sampling rate, Doppler-rate coefficients, and state-vector time, position, and velocity arrays. Geometry stores native trace points as [column, row] and geographic endpoints as [latitude, longitude]. Array calculations use [row, column] and record the conversion.")
    add_paragraph(doc, "For each ordered pair k, the executable builds matched Reference and Offset Doppler masks on the declared axis, reconstructs only that pair, and records the continuous intervals, discrete bins, centers, B-shift, K leap, and realized successive Offset-mask overlap.")
    add_paragraph(doc, "Version 1.8 records pair overlap as an exploratory bank variable. The former 5 percent successive Offset-edge rule is not a hard acceptance condition in the frozen ICEYE profile. A profile can enforce another limit only when it declares that policy before the run.")

    add_heading(doc, "3 Same-pair registration and canonical q")
    add_paragraph(doc, "Only the Reference and Offset reconstruction from the same k are registered. The frozen ICEYE profile uses a Context128 guarded extract with a central 32 by 32 complex phase-cross-correlation scoring patch, no intensity normalization, and 100-fold subpixel refinement. It records identity, reference-copy, and injected-shift controls; a failed control stops the run.")
    add_equation(doc, "Yₖ(P) = [Δx(P,k), Δy(P,k)]")
    add_paragraph(doc, "Two declared nuisance arcs use the identical estimator. The two-dimensional geometric median is calculated within each side, the side medians are averaged into G_arc,k, and the canonical residual is formed for every target P and pair k.")
    add_equation(doc, "qₖ(P) = Yₖ(P) − G_arc,k")
    add_paragraph(doc, "The numerical identity Y = G_arc + q is checked. Depth focus uses q, while Y and all nuisance vectors remain in the audit as controls.")

    add_heading(doc, "4 Explicit W50 eligibility hierarchy")
    add_paragraph(doc, "The following rules are the frozen ICEYE X13 Khafre profile carried by Version 1.8. Other experiments may declare other values, but must retain the same explicit hierarchy and save the corresponding masks.")
    add_table(doc, ["Stage", "Frozen operational rule"], [
        ["Modal candidate", "Use W=50 and choose one winning mode from m=1 through m=10 for each individual W start."],
        ["Ellipse gates", "The winning modal fit must have adjusted R² at least 0.25, minor semiaxis at least 0.005 native pixel, and b/a at least 0.10."],
        ["Track10", "Ten one-start-shifted W50 windows must all pass and have the same winning mode. This is a 59-pair family, not a pooled 500-vector fit."],
        ["Central K confinement", "Track10 family starts are K50 through K191, holding the entire 59-pair family inside K50 through K249."],
        ["Exact-start P support", "At one identical individual W50 start and same winning mode, P=4 or P=5 contiguous positions must be independently Track10-eligible."],
        ["Depth aggregation", "At each P and nominal depth, retain the largest adjusted R² only among accepted individual W starts and save the start that won."],
    ], [1.55, 5.9])
    add_paragraph(doc, "P=4 and P=5 are total contiguous sampled-position counts. They are not four or five pixels on each flank. Neighboring P positions may qualify through different Track10 families, but a start s must be shared exactly: a same-mode family at P40 near start 100 does not support a family at P41 near start 200.")

    add_heading(doc, "5 Conditional nominal-depth focus")
    add_paragraph(doc, "For every accepted individual W start s and every nominal depth z, take the matching q vectors q[s through s+49] and the matching Kz coefficients. A q window is never shifted against an unrelated K block. Fit both registered vector components independently to the real sine/cosine steering subspace:")
    add_equation(doc, "qₖ,c ≈ a_c cos(Kz,k z) + b_c sin(Kz,k z),    k = s … s+49")
    add_paragraph(doc, "For W=50, the conditional depth fit has 100 scalar observations and four fitted coefficients. Its adjusted R² is calculated from residual energy relative to the within-window q variance. At each retained P,z the display score is the maximum over accepted starts, not a sum, average, or support-count reward.")
    add_equation(doc, "S(P,z) = max over accepted s of adjusted R²(P,z;s)")
    add_paragraph(doc, "Several accepted W starts can therefore supply different nominal-depth lobes at one P position. A single W start can also produce periodic steering companions. The audit records recurrence and the winning W start, so neither behavior is concealed by the display.")

    add_heading(doc, "6 Kz geometry and depth statement")
    add_paragraph(doc, "For each frozen track, Version 1.8 recomputes the virtual aperture-plane baseline from the current state vectors and geometric midpoint. It records slant range, incidence, Doppler rate, baseline span, Kz span, and recurrence.")
    add_equation(doc, "Kz,k = 4π B⊥,k / (λ operational r sin θ)")
    add_paragraph(doc, "The z axis is nominal model depth. The operational wavelength is a declared depth-scale parameter. A calibration anchor is not an independent validation of absolute physical depth.")

    add_heading(doc, "7 Required audit and execution order")
    add_table(doc, ["Required output", "Content"], [
        ["Manifest and resolved profile", "Input hashes, HDF5 schema mapping, geometry hash, bank records, registration controls, gates, Kz audit, dependency versions, and output inventory."],
        ["Numerical NPZ audit", "Filter masks; Y; arcs; G_arc; q; registration errors; modal metrics; Track10 masks; P-support masks; scores; z grid; and winning W-start identities."],
        ["Display figure", "Conditional adjusted-R² tomograms. Display is clipped to 0 through 1 only; unsupported cells are black and numerical values are not smoothed or renormalized."],
    ], [2.0, 5.45])
    add_bullet(doc, "Validate the profile and input HDF5 schema, hash the SLC and frozen geometry, and construct the pair bank.")
    add_bullet(doc, "Reconstruct each matched pair, pass registration controls, measure target and nuisance vectors, and form q.")
    add_bullet(doc, "Apply modal ellipse gates, Track10, central-family confinement, and exact-start P support before depth fitting.")
    add_bullet(doc, "Recompute Kz from the current acquisition, fit every accepted W start at every z, save the complete audit, then interpret separately.")

    add_heading(doc, "8 Interpretation boundary")
    add_paragraph(doc, "Conditional adjusted R² is a normalized within-window model-fit metric. It is not displacement amplitude, probability, a count of independent detections, or proof of a void. Overlapping W starts and neighboring P positions are dependent samples. The executable preserves their provenance precisely so that alternative gate, bank, or steering analyses can be rerun without replacing the original vector record.")

    footer = section.footer.paragraphs[0]
    footer.alignment = WD_ALIGN_PARAGRAPH.CENTER
    set_run_font(footer.add_run("Biondi Subaperture Tomography Protocol Version 1.8"), size=8.5)
    doc.core_properties.title = "Biondi Subaperture Tomography Protocol Version 1.8"
    doc.core_properties.subject = "Standalone executable protocol and frozen W50 gate specification"
    doc.core_properties.author = "Biondi Protocol"
    doc.save(OUTPUT)


if __name__ == "__main__":
    build()
