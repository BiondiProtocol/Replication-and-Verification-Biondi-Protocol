# Place the two Khafre data files here

The frozen profile expects these unchanged filenames:

```text
ICEYE_X13_SLC_SLED_868226_20220715T235744.h5
ICEYE_X13_Khafre_Petrie_Dash_FourSides_H70p5m_FrozenGeometry.json
```

Neither source data file is included in this release package. Once both are in
this directory, run the commands in the package-root `README.md`.
