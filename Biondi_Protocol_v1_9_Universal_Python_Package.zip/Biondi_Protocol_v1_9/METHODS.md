# v1.9 computational specification

## Coordinates and registration

SLC axes are azimuth row and slant-range column. Input points are ordered
`[column,row]`. Registration returns the shift `[row,column]` that aligns the
moving image with its reference. Stored displacement vectors are reordered
`[range,azimuth]`; their alignment-shift sign is retained consistently.

For each pair, rectangular Doppler masks are centered at
`midpoint - separation/2` and `midpoint + separation/2`. Full inverse Fourier
reconstruction is the default. Optional chirp-z evaluation computes the same
band-limited inverse DFT over only the required rows; it changes computational
cost, not the source aperture, sampled positions or mask frequencies.

Registration first estimates a shift from the contextual frame, shifts the
moving contextual frame by that estimate, then estimates a residual shift
from the central core. Their sum is the reported shift. Complex unnormalized
cross-correlation and an upsampled matrix DFT are used. A planted displacement
control must pass the configured tolerance.

For each look, a geometric median of the measured flank vectors is computed
on each side. Their average is the reference correction:

\[
G_k=\tfrac12(\operatorname{gmed}Y_{k,+}+\operatorname{gmed}Y_{k,-}),
\qquad q_{p,k}=Y_{p,k}-G_k.
\]

Both flank medians and subtraction are in pixels, preserving the current
measurement convention. Before fitting, component spacings convert q to metres:
\(q^m=(s_r q_r,s_a q_a)\). A 1 m line sampling step does not imply 1 m native
image pixels or 1 m radar resolution.

## Geometry and the common time origin

Orbit states are interpolated with a cubic Hermite spline using ECEF position
and velocity. For each target, solve the declared Doppler convention

\[
f_D(t)=\sigma\frac{2}{\lambda_{radar}}
\mathbf v(t)\cdot\frac{\mathbf x-\mathbf s(t)}{|\mathbf x-\mathbf s(t)|},
\quad \sigma\in\{-1,+1\},
\]

first at zero Doppler, then at every bank midpoint. The zero-Doppler reference
provides a perpendicular-to-LOS orbit tangent. Project the sensor offset onto
that tangent to obtain baseline B. Range r and local incidence theta are
computed at each look. The phase history uses incremental baseline geometry:

\[
G_{p,k}=\frac{4\pi\,\Delta B_{p,k}}
{r_{p,k}\sin\theta_{p,k}\,\Delta t_{p,k}}\,(t_{p,k}-t_0),
\qquad \phi_{p,k}(z)=G_{p,k}\,I(z).
\]

`t0` is the acquisition start, common to all banks and sub-aperture designs.
The canonical array `acquisition_elapsed_time_s` is already `t - t0`.
For k>0, differences use adjacent bank looks. The first look copies the first
available adjacent delta-B and delta-t (the convention used in current runs).
Baselines are signed; elapsed time is not reset at K1 or each window.

If times are expressed relative to K1 for storage, add K1's acquisition-relative
time to recover `t - t0` before computing the phase. Dividing delta-B by delta-t
and multiplying by elapsed time cancels time units. Changing seconds to
milliseconds consistently leaves G unchanged. Changing the time origin changes
the model. A fraction of aperture time is unnecessary; it only preserves the
same expression if both increments and elapsed time use that same scale/origin.

Dimensional check: delta-B/r is dimensionless; `(t-t0)/delta-t` is dimensionless.
G has a radian convention and I is dimensionless. The exponent is dimensionless.

## Surface-to-depth integral

\[
I(z)=\int_0^z\frac{ds}{\ell(s)}.
\]

`phase_length_m` is the adopted propagation phase-length coefficient, not the
radar carrier wavelength. For a piecewise-constant profile:

\[
I(z)=\sum_j\frac{\max(0,\min(z,z_{j+1})-z_j)}{\ell_j}.
\]

The supplied Giza Mokattam limestone reference uses a 2.4 m boundary and
coefficients 0.036858797794585174 m / 0.08074816571554078 m above/below.
These encode the adopted reference model and calibration, not transferable
geological constants. A different material profile changes nominal depth
steering. No unknown true-depth correction is automatically applied.

## Ellipse fitting and score

At every position p, candidate depth z and contiguous W-vector window, fit
both metre components simultaneously to

\[
q^m_{p,k}\simeq\mathbf a\cos\phi_{p,k}(z)+\mathbf b\sin\phi_{p,k}(z).
\]

There is no free constant offset. The design has two columns and the two
components contribute four fitted coefficients. Fits use prefix sufficient
statistics, exactly equivalent to direct least squares for nonsingular designs.
Require `det(X'X) > 1e-10 trace(X'X)^2` to avoid rank degeneracy.

Let SSE sum squared residuals over both components and SST sum deviations from
the component means in that same window. The displayed adjusted score is

\[
R^2_{adj}=1-\frac{\mathrm{SSE}}{\mathrm{SST}}
\frac{2W-1}{2W-5}.
\]

The ellipse semiaxes are the singular values of the 2x2 coefficient matrix.
If enabled, strict `minor/major > axis_ratio_min` eligibility is applied before
window selection. Evaluate every `K-W+1` start, using every W vector in each
fit. Select the greatest eligible score independently for each position/depth;
exact ties choose the earliest window. Window winners need not be shared
between neighboring positions.

At each depth, retain every member of a consecutive run of strictly positive,
finite best scores whose length is at least P. No shared-start-zone or Track
support is required. Negative scores are preserved in `best_eligible_score`;
zero is only the display value for nonpositive or unsupported cells. No
smoothing is applied. The winning window index is zero-based in the bank.
The first bank pair is therefore start index 0.

## Coverage and diagnostics

The canonical run is full, with no sampled depths, positions or window starts.
Depth chunks and column groups are computational partitions. Overlapping
sub-apertures are not asserted to be statistically independent looks.
Held-out prediction and permutation diagnostics are not canonical eligibility
gates in v1.9. They remain separate experiments. Aperture width, Doppler leap,
mask overlap, W and P are configuration choices, not universal optimal values.
