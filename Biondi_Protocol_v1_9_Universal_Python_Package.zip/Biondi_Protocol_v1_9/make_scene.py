"""Optional regional straight-line placement from geographic endpoints and RPC."""
import argparse,json,numpy as np
from biondi_protocol.placement import RPC,EGM96Interpolator,en

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--corners',required=True);p.add_argument('--rpc',required=True);p.add_argument('--out',required=True);p.add_argument('--geoid-grid');args=p.parse_args();j=json.load(open(args.corners));a=j['start'];b=j['end'];A=np.array([a['latitude_deg'],a['longitude_deg']]);B=np.array([b['latitude_deg'],b['longitude_deg']]);length=float(np.linalg.norm(en(A,B)));step=float(j.get('sampling_m',1))
 if length<=0 or step<=0:raise ValueError('Nonzero line length and positive sample spacing required')
 distance=np.arange(0,length,step);distance=np.r_[distance,length];frac=distance/length;ll=A+frac[:,None]*(B-A)
 if args.geoid_grid:
  g=EGM96Interpolator(args.geoid_grid);h=a['height_orthometric_m']+frac*(b['height_orthometric_m']-a['height_orthometric_m']);hae=h+np.array([g.undulation_m(*point) for point in ll])
 else:hae=a['height_ellipsoid_m']+frac*(b['height_ellipsoid_m']-a['height_ellipsoid_m'])
 rpc=RPC(args.rpc);raw=np.array([rpc.project(point,h) for point,h in zip(ll,hae)]);initial=float(j['zero_doppler_first_row_time_s'])+raw[:,1]*float(j['azimuth_row_interval_s'])
 np.savez_compressed(args.out,target_col_row=raw,target_lon_lat_hae_m=np.column_stack([ll[:,1],ll[:,0],hae]),initial_time_s=initial,distance_m=distance)
 print(json.dumps({'positions':len(raw),'length_m':length,'P0':'start','last_position':'end','placement':'Regional local-metric straight-line approximation'}))
if __name__=='__main__':main()
