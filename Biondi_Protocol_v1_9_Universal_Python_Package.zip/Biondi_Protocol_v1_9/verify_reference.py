"""Reproduce the full saved fit and orbit conformance checks after a restart."""
import os
for name in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[name]='1'
from pathlib import Path
import argparse,json,numpy as np
from biondi_protocol.cli import arrays,load_config,run_focus
from biondi_protocol.geometry import from_orbit

def main():
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--out',default='reference_validation');args=parser.parse_args();root=Path(__file__).resolve().parent;out=Path(args.out);data=arrays(root/'examples/reference_input.npz');expected=arrays(root/'examples/reference_expected.npz');c=load_config(root/'examples/giza_reference.json');result,_=run_focus(data,c,out,True)
 assert np.array_equal(result['score'],expected['score']), 'Reference scores differ'
 assert np.array_equal(result['pixel_support_mask'],expected['pixel_support_mask']), 'Reference support differs'
 c=load_config(root/'examples/reference_slc_rebuild.json');b=c['bank'];mid=(b['midpoint_start_bin']+b['midpoint_step_bins']*np.arange(b['pairs']))/b['aperture_duration_s'];g=from_orbit(arrays(c['geometry']['orbit_path']),arrays(c['geometry']['scene_path']),mid,c['sensor'],c['geometry']);difference=float(abs(g['phase_geometry_rate_times_elapsed']-data['phase_geometry_rate_times_elapsed']).max());assert difference<1e-9,difference
 report={'positions':217,'pairs':295,'window_starts':121,'depths':999,'scores_bitwise_identical':True,'pixel_support_identical':True,'max_phase_geometry_difference':difference,'coverage':'Full saved reference inversion and orbit; raw source SLC not rebuilt'};(out/'conformance.json').write_text(json.dumps(report,indent=2));print(json.dumps(report),flush=True)
if __name__=='__main__':main()
