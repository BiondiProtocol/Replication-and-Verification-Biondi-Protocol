import unittest,sys,tempfile,json
from pathlib import Path
import numpy as np
from scipy.ndimage import fourier_shift
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from biondi_protocol.focus import layer_integral,time_variant_rate,pixel_support,focus
from biondi_protocol.measurement import register,measure
from biondi_protocol.statistics import statistics,all_windows,from_statistics

class ProtocolTests(unittest.TestCase):
    def test_layer_integral_and_time_units(self):
        model={'layers':[{'bottom_m':2,'phase_length_m':.5},{'bottom_m':None,'phase_length_m':1}]}
        np.testing.assert_allclose(layer_integral([0,1,2,3],model),[0,2,4,5])
        b=np.tile(np.arange(5,dtype=float)[:,None],(1,2));t=b*.2+3;r=np.full_like(b,100);theta=np.full_like(b,30)
        # A common change of time unit cancels. Changing the origin does not.
        np.testing.assert_allclose(time_variant_rate(b,t,r,theta),time_variant_rate(b,t*1000,r,theta))
        self.assertFalse(np.allclose(time_variant_rate(b,t,r,theta),time_variant_rate(b,t+1,r,theta)))
    def test_support_arbitrary_position_count(self):
        a=np.array([[1],[1],[1],[-1],[1],[1]],dtype=float)
        np.testing.assert_array_equal(pixel_support(a,3).ravel(),[True,True,True,False,False,False])
    def test_prefix_against_direct_no_offset_fit(self):
        rng=np.random.default_rng(93);q=rng.normal(size=(4,17,2));phase=rng.normal(size=(4,3,17));c=np.cos(phase);s=np.sin(phase);w=9
        st=all_windows(statistics(q,c,s,np.ones(17,bool)),w);score,ba,_=from_statistics(st,st)
        for start in (0,4,8):
            for p in range(4):
                for d in range(3):
                    design=np.column_stack([c[p,d,start:start+w],s[p,d,start:start+w]]);y=q[p,start:start+w];coef=np.linalg.lstsq(design,y,rcond=None)[0];sse=((y-design@coef)**2).sum();sst=((y-y.mean(0))**2).sum();expected=1-sse/sst*(2*w-1)/(2*w-5);sv=np.linalg.svd(coef,compute_uv=False)
                    self.assertAlmostEqual(float(score[start,p,d]),expected,places=10);self.assertAlmostEqual(float(ba[start,p,d]),sv[-1]/sv[0],places=9)
    def test_generic_bank_and_scene_counts(self):
        rng=np.random.default_rng(29);n,k=11,23;rate=np.linspace(.2,1.7,k)[:,None]+np.arange(n)[None,:]*.01;depth=np.array([.2,.5,1.0]);q=rng.normal(size=(n,k,2))
        result=focus(q,[.3,.1],rate,depth,depth*2,{'window_vectors':13,'pixel_support':2,'axis_ratio_min':None,'depth_chunk':2})
        self.assertEqual(result['score'].shape,(11,3));self.assertTrue(np.isfinite(result['score']).all())
    def test_registration_and_compact_bank(self):
        rng=np.random.default_rng(21);settings={'support_shape_azimuth_range':[32,32],'core_shape_azimuth_range':[16,16],'upsample_factor':100,'flank_offset_pixels':20,'flank_count_per_side':3,'planted_shift_row_col':[.73,-.41],'control_limit_pixels':.05,'column_group_pixels':128}
        a=rng.normal(size=(32,32))+1j*rng.normal(size=(32,32));plant=np.array([.73,-.41]);b=np.fft.ifftn(fourier_shift(np.fft.fftn(a),plant));np.testing.assert_allclose(register(a,b,settings),-plant,atol=.05)
        with tempfile.TemporaryDirectory() as tmp:
            slc=(rng.normal(size=(256,128))+1j*rng.normal(size=(256,128))).astype(np.complex64);path=Path(tmp)/'slc.npy';np.save(path,slc)
            scene={'target_col_row':np.array([[55,100],[60,110],[65,120],[70,130]],float)};source={'format':'npy_complex','path':str(path)};bank={'pairs':3,'midpoint_start_bin':-4,'midpoint_step_bins':4,'mask_bins':101,'reference_offset_separation_bins':8,'azimuth_sampling_hz':1000}
            full,_=measure(scene,source,bank,settings);compact,_=measure(scene,source,bank,{**settings,'compact_inverse':True})
            np.testing.assert_array_equal(full['raw_shift_px'],compact['raw_shift_px']);np.testing.assert_array_equal(full['q'],compact['q'])

if __name__=='__main__':unittest.main()
