# Input contract

All numeric NPZ arrays use `allow_pickle=False`. One ordered line per run;
process multiple lines by invoking the same configuration with different scenes.
Time arrays in every input use seconds since one declared acquisition start.
Keep that origin fixed when comparing different bank designs.

## Restart input (NPZ)

Required:

| Key | Shape | Meaning |
|---|---|---|
| `q` | N×K×2 | Flank-corrected alignment shifts, pixels, component order range/azimuth |
| `range_azimuth_spacing_m` | 2 | Positive native component sampling spacings, metres |
| `phase_geometry_rate_times_elapsed` | K×N | G from METHODS.md |
| `distance_m` | N | Ordered physical position distances along the line |

Instead of G, supply `baseline_perp_m`, `acquisition_elapsed_time_s`,
`slant_range_m` and `local_incidence_angle_deg`, all K×N. The code computes G.
`depth_m` and `layer_integral` are optional saved arrays, required only for
`--use-saved-depth-model`. Without that flag, JSON defines the depth profile.
Saved acquisition time is not silently reset at a window or bank boundary.

## SLC source

Rows are azimuth samples; columns are slant range. Source JSON specifies
`format`, `path`, optional HDF5 dataset names, optional local row/column intervals,
and optional `native_origin_col_row`. The origin describes the native pixel
indices corresponding to file-local `[column=0,row=0]`. It is essential for
cropped source files. Do not substitute ground-range GRD pixel spacing.

`azimuth_sampling_hz` is the sampling rate of the delivered complex array, not
necessarily the radar acquisition PRF. FFT bin spacing is that rate divided by
selected row count. Optional `aperture_duration_s` must agree with this duration.
Mask width is an odd integer of FFT bins; R/O separation is a positive even
integer of bins. Midpoint indices must increase; selected masks must remain
inside the sampled spectrum.

## Scene input (NPZ)

| Key | Shape | Meaning |
|---|---|---|
| `target_col_row` | N×2 | Floating native image coordinates; nearest pixel is registered |
| `target_lon_lat_hae_m` | N×3 | Longitude degrees, latitude degrees, WGS84 ellipsoid height metres |
| `initial_time_s` | N | Initial zero-Doppler solve guesses relative to acquisition start |
| `distance_m` | N | Monotonic distance along the ordered line |
| `flank_col_row` | 2×J×2, optional | Supplied native pixel flank centres |

If flank centres are omitted, generate J samples on each side offset in native
pixel coordinates normal to the image line. The configured pixel offset is
not a metre distance. All complete target/flank supports must fit inside the
selected source tile. Ground heights must be ellipsoid heights, not uncorrected
orthometric heights. For geoid undulation N, `HAE = orthometric height + N`.

## Orbit input (NPZ)

| Key | Shape | Meaning |
|---|---|---|
| `time_s` | S | Strictly increasing seconds since acquisition start |
| `position_ecef_m` | S×3 | Earth-fixed sensor positions |
| `velocity_ecef_mps` | S×3 | Earth-fixed sensor velocities |

All solved look times and finite-difference probes must lie inside orbit
coverage; extrapolation is rejected. Sensor JSON supplies carrier wavelength
and Doppler sign. Do not infer either from a different collection.

## Optional RPC and geoid input

RPC NPZ uses standard 20-term coefficient order in `placement.terms`, with
`LONG/LAT/HEIGHT_OFF`, corresponding `_SCALE`, `LINE/SAMP_OFF`, their `_SCALE`,
and `LINE/SAMP_NUM_COEFF` / `LINE/SAMP_DEN_COEFF`. Optional `crop_row0` and
`crop_col0` restore cropped offsets. Confirm your provider's term order before
using this adapter. Other geolocation models can supply canonical scene arrays.

A local EGM96 NPZ has `grid` (4×4 posts), `row0`, `col0`, matching the documented
quarter-degree grid indexing in `placement.py`. The interpolator deliberately
rejects points outside that patch; supply a new patch for a different location.

The corner JSON template uses start/end latitudes, longitudes and ellipsoid
heights, `sampling_m`, `zero_doppler_first_row_time_s`, and
`azimuth_row_interval_s`. With `--geoid-grid`, use `height_orthometric_m` in
place of `height_ellipsoid_m`.

## Output

`result.npz` preserves scores, raw eligible best scores (including negative
values), winning window starts, support mask, depth integral/grid, phase
geometry, distances and position indices. Report JSON records resolved settings,
full processing coverage, positive fraction and peak, if any.

The generic readers do not automatically parse every supplier's product metadata.
Explicit normalization into these arrays is the portability boundary. This
package supports arbitrary scenes/sensors through that interface, rather than
claiming automatic compatibility with every proprietary container.
