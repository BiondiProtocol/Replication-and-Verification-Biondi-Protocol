"""Registration primitives retained from the verified implementation."""
import math
import numpy as np

def wgs84_ecef(longitude_deg: float, latitude_deg: float, hae_m: float) -> np.ndarray:
    semimajor = 6_378_137.0
    flattening = 1.0 / 298.257223563
    eccentricity_sq = flattening * (2.0 - flattening)
    longitude = math.radians(longitude_deg)
    latitude = math.radians(latitude_deg)
    radius = semimajor / math.sqrt(1.0 - eccentricity_sq * math.sin(latitude) ** 2)
    return np.array(
        [
            (radius + hae_m) * math.cos(latitude) * math.cos(longitude),
            (radius + hae_m) * math.cos(latitude) * math.sin(longitude),
            (radius * (1.0 - eccentricity_sq) + hae_m) * math.sin(latitude),
        ],
        dtype=np.float64,
    )

def ellipsoid_normal(longitude_deg: float, latitude_deg: float) -> np.ndarray:
    longitude = math.radians(longitude_deg)
    latitude = math.radians(latitude_deg)
    return np.array(
        [math.cos(latitude) * math.cos(longitude), math.cos(latitude) * math.sin(longitude), math.sin(latitude)],
        dtype=np.float64,
    )

def geometric_median(points: np.ndarray, tolerance: float = 1e-9, max_iterations: int = 200) -> np.ndarray:
    values = np.asarray(points, dtype=np.float64)
    estimate = np.median(values, axis=0)
    for _ in range(max_iterations):
        distance = np.linalg.norm(values - estimate, axis=1)
        exact = np.flatnonzero(distance < tolerance)
        if exact.size:
            return values[exact[0]].copy()
        weights = 1.0 / distance
        updated = np.sum(values * weights[:, None], axis=0) / np.sum(weights)
        if float(np.linalg.norm(updated - estimate)) < tolerance:
            return updated
        estimate = updated
    return estimate

def normalized_complex_coherence(reference: np.ndarray, moving: np.ndarray) -> float:
    numerator = np.vdot(reference, moving)
    denominator = math.sqrt(float(np.vdot(reference, reference).real * np.vdot(moving, moving).real))
    return float(abs(numerator) / denominator) if denominator else float("nan")

def _upsampled_dft(
    data: np.ndarray,
    upsampled_region_size: tuple[int, int],
    upsample_factor: float,
    axis_offsets: np.ndarray,
) -> np.ndarray:
    """Matrix-multiply DFT refinement from Guizar--Sicairos."""
    result = data
    imaginary_two_pi = 1j * 2.0 * np.pi
    for n_items, region_size, axis_offset in zip(
        result.shape[::-1], upsampled_region_size[::-1], axis_offsets[::-1]
    ):
        kernel = (
            (np.arange(region_size, dtype=np.float64)[:, None] - axis_offset)
            * np.fft.ifftshift(np.arange(n_items))[None, :]
        )
        kernel = np.exp((-imaginary_two_pi / (n_items * upsample_factor)) * kernel)
        result = np.tensordot(kernel, result, axes=(1, -1))
    return result

def phase_cross_correlation_none(reference: np.ndarray, moving: np.ndarray, upsample_factor=100) -> np.ndarray:
    """Return complex unnormalized [row, col] shift aligning moving to reference."""
    if reference.shape != moving.shape:
        raise ValueError("registration frames must have identical shapes")
    source_frequency = np.fft.fftn(reference)
    moving_frequency = np.fft.fftn(moving)
    image_product = source_frequency * moving_frequency.conj()
    correlation = np.fft.ifftn(image_product)
    maxima = np.array(np.unravel_index(np.argmax(np.abs(correlation)), reference.shape), dtype=np.float64)
    midpoints = np.array([np.trunc(size / 2.0) for size in reference.shape])
    shifts = maxima.copy()
    shifts[shifts > midpoints] -= np.asarray(reference.shape)[shifts > midpoints]
    factor = float(upsample_factor)
    shifts = np.round(shifts * factor) / factor
    region_size = int(math.ceil(factor * 1.5))
    dftshift = float(math.trunc(region_size / 2.0))
    sample_region_offset = dftshift - shifts * factor
    correlation = _upsampled_dft(
        image_product.conj(), (region_size, region_size), factor, sample_region_offset
    ).conj()
    maxima = np.array(np.unravel_index(np.argmax(np.abs(correlation)), correlation.shape), dtype=np.float64)
    maxima -= dftshift
    return shifts + maxima / factor
