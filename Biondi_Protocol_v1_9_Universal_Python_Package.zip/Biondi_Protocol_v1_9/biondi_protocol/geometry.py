"""Provider-independent orbit geometry: canonical ECEF states and target LLH."""
import numpy as np
from scipy.interpolate import CubicHermiteSpline
from .primitives import wgs84_ecef, ellipsoid_normal
from .focus import time_variant_rate


def from_orbit(orbit_data, scene, midpoint_hz, sensor, settings):
    times = np.asarray(orbit_data['time_s'],dtype=float)
    positions = np.asarray(orbit_data['position_ecef_m'],dtype=float)
    velocities = np.asarray(orbit_data['velocity_ecef_mps'],dtype=float)
    if times.ndim != 1 or len(times)<2 or np.any(np.diff(times)<=0) or positions.shape!=(len(times),3) or velocities.shape!=positions.shape:
        raise ValueError('Orbit needs increasing acquisition-relative times and matching ECEF states')
    spline = CubicHermiteSpline(times,positions,velocities,axis=0,extrapolate=False)
    llh = np.asarray(scene['target_lon_lat_hae_m'],dtype=float)
    initial = np.asarray(scene['initial_time_s'],dtype=float)
    if llh.ndim!=2 or llh.shape[1]!=3 or initial.shape!=(len(llh),):
        raise ValueError('Scene requires [N,3] longitude,latitude,ellipsoid height and [N] initial times')
    wavelength = float(sensor['carrier_wavelength_m']); sign = float(sensor.get('doppler_sign',-1))
    if wavelength<=0 or sign not in (-1,1): raise ValueError('Invalid carrier wavelength or Doppler sign')
    epsilon = float(settings.get('doppler_epsilon_s',.001))
    if epsilon<=0: raise ValueError('Doppler derivative step must be positive')
    def doppler(target,t):
        los = target-spline(t); los /= np.linalg.norm(los)
        return sign*2/wavelength*np.dot(spline(t,1),los)
    def solve(target,t,frequency):
        for _ in range(int(settings.get('newton_iterations',5))):
            if not times[0]+epsilon <= t <= times[-1]-epsilon: raise ValueError('Look time leaves orbit coverage')
            residual = doppler(target,t)-frequency
            derivative = (doppler(target,t+epsilon)-doppler(target,t-epsilon))/(2*epsilon)
            if abs(derivative)<float(settings.get('minimum_doppler_rate_hz_per_s',1)):
                raise ValueError('Doppler derivative is too small')
            step = residual/derivative
            if abs(step)>float(settings.get('max_newton_step_s',1)):
                raise ValueError('Doppler solve exceeds configured step bound')
            t -= step
        if not times[0]+epsilon <= t <= times[-1]-epsilon: raise ValueError('Solved look time leaves orbit coverage')
        if abs(doppler(target,t)-frequency)>float(settings.get('residual_limit_hz',.01)):
            raise ValueError('Doppler-time solve did not converge')
        return t
    k,n = len(midpoint_hz),len(llh); b=np.empty((k,n)); t=np.empty_like(b); r=np.empty_like(b); inc=np.empty_like(b); reference=np.empty(n)
    for p,(lon,lat,height) in enumerate(llh):
        target=wgs84_ecef(float(lon),float(lat),float(height)); normal=ellipsoid_normal(float(lon),float(lat))
        zero=solve(target,float(initial[p]),0); reference[p]=zero; s0=spline(zero); v0=spline(zero,1); los=target-s0;los/=np.linalg.norm(los)
        tangent=v0-np.dot(v0,los)*los;tangent/=np.linalg.norm(tangent)
        derivative=(doppler(target,zero+epsilon)-doppler(target,zero-epsilon))/(2*epsilon)
        for look,frequency in enumerate(midpoint_hz):
            current=solve(target,zero+frequency/derivative,float(frequency)); sensor_position=spline(current)
            b[look,p]=np.dot(sensor_position-s0,tangent);t[look,p]=current
            direction=sensor_position-target;r[look,p]=np.linalg.norm(direction);direction/=r[look,p]
            inc[look,p]=np.rad2deg(np.arccos(np.clip(np.dot(direction,normal),-1,1)))
    rate=time_variant_rate(b,t,r,inc)
    return dict(baseline_perp_m=b,acquisition_elapsed_time_s=t,slant_range_m=r,local_incidence_angle_deg=inc,reference_time_s=reference,phase_geometry_rate_times_elapsed=rate)
