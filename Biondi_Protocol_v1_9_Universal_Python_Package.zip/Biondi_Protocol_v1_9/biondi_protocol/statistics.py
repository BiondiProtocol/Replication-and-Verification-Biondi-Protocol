"""Verified prefix-statistic, no-offset ellipse fits; components in metres."""
import numpy as np

def prefix(a):
 return np.concatenate([np.zeros(a.shape[:-1]+(1,)),np.cumsum(a,axis=-1)],axis=-1)

def statistics(y,c,s,mask):
 m=mask.astype(float);return {'cc':prefix(c*c*m),'ss':prefix(s*s*m),'cs':prefix(c*s*m),'yc':prefix(c[...,None,:]*y[:,None].transpose(0,1,3,2)*m),'ys':prefix(s[...,None,:]*y[:,None].transpose(0,1,3,2)*m),'yy':prefix((y*y).sum(-1)*m),'sum':prefix(y.transpose(0,2,1)*m),'n':prefix(m)}

def all_windows(st,W):
 values={k:np.moveaxis(v[...,W:]-v[...,:-W],-1,0) for k,v in st.items()}
 return values

def from_statistics(t,v):
 cc,ss,cs=t['cc'],t['ss'],t['cs'];det=cc*ss-cs*cs;valid=det>1e-10*(cc+ss)**2;inv=np.divide(1,det,out=np.zeros_like(det),where=valid)
 bc=(ss[...,None]*t['yc']-cs[...,None]*t['ys'])*inv[...,None];bs=(cc[...,None]*t['ys']-cs[...,None]*t['yc'])*inv[...,None]
 sse=np.maximum(0,t['yy'][...,None]-(bc*t['yc']+bs*t['ys']).sum(-1));sst=t['yy']-(t['sum']*t['sum']).sum(-1)/np.asarray(t['n'])[...,None];score=1-np.divide(sse,sst[...,None],out=np.full_like(sse,np.inf),where=sst[...,None]>0)*np.asarray((2*t['n']-1)/(2*t['n']-5))[...,None,None];score=np.where(valid,score,-np.inf)
 aa=(bc*bc).sum(-1);bb=(bs*bs).sum(-1);ab=(bc*bs).sum(-1);tr=aa+bb;disc=np.sqrt(np.maximum(0,(aa-bb)**2+4*ab**2));major=(tr+disc)/2;minor=np.maximum(0,(tr-disc)/2);ba=np.sqrt(np.divide(minor,major,out=np.zeros_like(minor),where=major>0))
 rss=v['yy'][...,None]-2*(bc*v['yc']+bs*v['ys']).sum(-1)+v['cc']*aa+v['ss']*bb+2*v['cs']*ab
 mean=t['sum']/np.asarray(t['n'])[...,None,None];base=v['yy']-2*(mean*v['sum']).sum(-1)+np.asarray(v['n'])[...,None]*(mean*mean).sum(-1)
 pred=1-np.divide(np.maximum(0,rss),base[...,None],out=np.full_like(rss,np.inf),where=base[...,None]>0)
 return score,ba,pred
