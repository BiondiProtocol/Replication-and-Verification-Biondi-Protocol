"""Complex-SLC readers, Doppler-bank generation and flank-corrected shifts."""
from pathlib import Path
import numpy as np
from scipy.fft import fft, fftshift, ifft, ifftshift, fftn, ifftn
from scipy.ndimage import fourier_shift
from scipy.signal import CZT
from .primitives import phase_cross_correlation_none, geometric_median, normalized_complex_coherence


class SLCReader:
    """Explicit adapters: HDF5 I/Q or complex, NPY complex, complex TIFF."""
    def __init__(self, settings):
        self.settings=settings; self.handle=None; kind=settings['format'];path=Path(settings['path'])
        if kind in ('h5_split','h5_complex'):
            import h5py
            self.handle=h5py.File(path,'r')
            if kind=='h5_split':
                self.real=self.handle[settings.get('real_key','s_i')];self.imag=self.handle[settings.get('imag_key','s_q')]
                if self.real.shape!=self.imag.shape: self.close();raise ValueError('I/Q shapes differ')
                self.data=None;self.shape=self.real.shape
            else: self.data=self.handle[settings.get('complex_key','slc')];self.shape=self.data.shape
        elif kind=='npy_complex':self.data=np.load(path,mmap_mode='r',allow_pickle=False);self.shape=self.data.shape
        elif kind=='tiff_complex':
            import tifffile
            self.data=tifffile.memmap(path);self.shape=self.data.shape
        else:raise ValueError('Unsupported SLC format; provide an explicit complex-array adapter')
        if len(self.shape)!=2: self.close();raise ValueError('SLC must have [azimuth row, range column] axes')
        if self.data is not None and not np.issubdtype(self.data.dtype,np.complexfloating): self.close();raise ValueError('SLC must be complex, not intensity')
    def read(self,rows,columns):
        if self.data is None: return (np.asarray(self.real[rows,columns],dtype=np.float32)+1j*np.asarray(self.imag[rows,columns],dtype=np.float32)).astype(np.complex64)
        return np.asarray(self.data[rows,columns],dtype=np.complex64)
    def close(self):
        if self.handle is not None:self.handle.close()


def register(reference,moving,settings):
    up=int(settings['upsample_factor']);coarse=phase_cross_correlation_none(reference,moving,up)
    aligned=ifftn(fourier_shift(fftn(moving),coarse))
    shape=np.asarray(reference.shape);core=np.asarray(settings['core_shape_azimuth_range'],dtype=int)
    start=(shape-core)//2;sl=tuple(slice(int(a),int(a+b)) for a,b in zip(start,core))
    return coarse+phase_cross_correlation_none(reference[sl],aligned[sl],up)


def flank_centres(target,settings):
    delta=np.asarray(target[-1]-target[0],dtype=float)
    if np.linalg.norm(delta)==0:raise ValueError('Line endpoints coincide')
    normal=np.array([-delta[1],delta[0]])/np.linalg.norm(delta)
    indices=np.rint(np.linspace(0,len(target)-1,int(settings['flank_count_per_side']))).astype(int)
    offset=float(settings['flank_offset_pixels'])*normal
    return np.stack([np.rint(target[indices]+offset),np.rint(target[indices]-offset)]).astype(int)


def measure(scene,source,bank,settings,progress=None):
    target_raw=np.asarray(scene['target_col_row'],dtype=float)
    if target_raw.ndim!=2 or target_raw.shape[1]!=2 or len(target_raw)<2 or not np.isfinite(target_raw).all(): raise ValueError('Scene targets must be finite [N,2] col,row')
    target=np.floor(target_raw+.5).astype(int)
    flanks=np.asarray(scene['flank_col_row'],dtype=int) if 'flank_col_row' in scene else flank_centres(target_raw,settings)
    if flanks.ndim!=3 or flanks.shape[0]!=2 or flanks.shape[2]!=2 or flanks.shape[1]<1:raise ValueError('Flanks must be [2,J,2] col,row')
    points=np.concatenate([target,flanks.reshape(-1,2)]);n=len(target);j=flanks.shape[1]
    support=np.asarray(settings['support_shape_azimuth_range'],dtype=int);core=np.asarray(settings['core_shape_azimuth_range'],dtype=int)
    if support.shape!=(2,) or core.shape!=(2,) or np.any(support%2) or np.any(core%2) or np.any(core<2) or np.any(core>support): raise ValueError('Support/core must be positive even sizes, with core inside support')
    half=support//2;k=int(bank['pairs']);width=int(bank['mask_bins']);separation=int(bank['reference_offset_separation_bins'])
    if k<2 or width<1 or width%2!=1 or separation<=0 or separation%2:raise ValueError('Need K>=2, odd mask width and positive even R/O separation')
    mid=int(bank['midpoint_start_bin'])+int(bank['midpoint_step_bins'])*np.arange(k)
    if np.any(np.diff(mid)<=0):raise ValueError('Bank midpoints must strictly increase')
    reader=SLCReader(source)
    try:
        rows=source.get('source_row_interval') or [0,reader.shape[0]];cols=source.get('source_column_interval') or [0,reader.shape[1]]
        r0,r1=map(int,rows);c0,c1=map(int,cols)
        if not (0<=r0<r1<=reader.shape[0] and 0<=c0<c1<=reader.shape[1]):raise ValueError('Source intervals leave the SLC')
        origin=np.asarray(source.get('native_origin_col_row',[0,0]),dtype=int)+[c0,r0]
        local=points-origin;N=r1-r0
        if np.any(local[:,0]-half[1]<0) or np.any(local[:,0]+half[1]>c1-c0) or np.any(local[:,1]-half[0]<0) or np.any(local[:,1]+half[0]>N):raise ValueError('Full support for target/flank leaves the source tile')
        fs=float(bank['azimuth_sampling_hz']);duration=float(bank.get('aperture_duration_s') or N/fs)
        if fs<=0 or duration<=0 or not np.isclose(duration,N/fs,rtol=1e-6):raise ValueError('FFT duration must equal selected row count / azimuth sampling frequency')
        frequency=mid/duration
        if N//2+mid.min()-separation//2-width//2<0 or N//2+mid.max()+separation//2+width//2+1>N:raise ValueError('Requested masks leave the FFT spectrum')
        y=np.empty((k,n,2),np.float32);arc=np.empty((k,2,j,2),np.float32);coherence=np.empty((k,n),np.float32)
        group_width=int(settings.get('column_group_pixels',256))
        if group_width<1:raise ValueError('Column group size must be positive')
        groups=(local[:,0]-local[:,0].min())//group_width;ids=np.unique(groups);control=None
        for g in ids:
            records=np.flatnonzero(groups==g);lo=int(local[records,0].min()-half[1]);hi=int(local[records,0].max()+half[1]);signal=reader.read(slice(r0,r1),slice(c0+lo,c0+hi));spec=fftshift(fft(signal,axis=0,workers=1),axes=0);del signal
            compact=bool(settings.get('compact_inverse',False));start=int(local[records,1].min()-half[0]);stop=int(local[records,1].max()+half[0])
            if compact: transform=CZT(n=width,m=stop-start,w=np.exp(2j*np.pi/N),a=np.exp(-2j*np.pi*start/N));samples=np.arange(start,stop)
            def image(centre):
                low=N//2+int(centre)-width//2
                if compact:return (transform(spec[low:low+width],axis=0)*np.exp(2j*np.pi*(centre-width//2)*samples/N)[:,None]/N).astype(np.complex64),start
                masked=np.zeros_like(spec);masked[low:low+width]=spec[low:low+width]
                return ifft(ifftshift(masked,axes=0),axis=0,workers=1).astype(np.complex64),0
            def frame(img,index):
                a,offset=img;col,row=local[index];col-=lo;row-=offset
                return a[row-half[0]:row+half[0],col-half[1]:col+half[1]]
            if control is None:
                ref=image(mid[k//2]-separation//2);ref=frame(ref,int(records[0]));injected=np.asarray(settings['planted_shift_row_col']);planted=ifftn(fourier_shift(fftn(ref),injected));recovered=register(ref,planted,settings);error=float(abs(recovered+injected).max());control={'injected_shift_row_col':injected.tolist(),'recovered_alignment_shift_row_col':recovered.tolist(),'max_error_pixels':error,'passed':error<=settings['control_limit_pixels']}
                if not control['passed']:raise RuntimeError('Planted displacement control failed')
            for look,m in enumerate(mid):
                ref=image(m-separation//2);mov=image(m+separation//2)
                for index in records:
                    a=frame(ref,int(index));b=frame(mov,int(index));shift=register(a,b,settings)[::-1].astype(np.float32)
                    if index<n:y[look,index]=shift;coherence[look,index]=normalized_complex_coherence(a,b)
                    else:f,sub=divmod(int(index-n),j);arc[look,f,sub]=shift
                if progress:progress(int(g),int(look+1),k)
            del spec
        med=np.empty((k,2,2),np.float32)
        for look in range(k):
            for flank in range(2):med[look,flank]=geometric_median(arc[look,flank]).astype(np.float32)
        correction=.5*(med[:,0]+med[:,1]);q=y-correction[:,None,:]
        return dict(q=q.transpose(1,0,2),raw_shift_px=y,flank_shift_px=arc,flank_geometric_median_px=med,arc_correction_px=correction,coherence=coherence,midpoint_bins=mid,midpoint_hz=frequency),dict(control=control,positions=n,pairs=k,registrations=k*(n+2*j),source_rows=[r0,r1],source_columns=[c0,c1],aperture_duration_s=duration,complete=True)
    finally:reader.close()
