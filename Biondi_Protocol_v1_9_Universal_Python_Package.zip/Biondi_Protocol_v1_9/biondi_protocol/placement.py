"""Standard 20-term RPC mapping and optional local EGM96 spline.
All coefficient files and geoid grids are supplied by the caller.
"""
from pathlib import Path
import numpy as np
from scipy.optimize import least_squares
GRID_SPACING_DEG=.25
GRID_PADDING=2

class EGM96Interpolator:
    """NGA INTPT.F-compatible four-by-four natural-spline EGM96 evaluator."""

    def __init__(self,path):
        with np.load(path) as d:
            self._grid=d['grid'];self.row0=int(d['row0']);self.col0=int(d['col0'])

    @staticmethod
    def _moments(values: np.ndarray) -> np.ndarray:
        size = len(values)
        moments = np.zeros(size, dtype=np.float64)
        workspace = np.zeros(size, dtype=np.float64)
        for index in range(1, size - 1):
            pivot = workspace[index - 1] / 2.0 + 2.0
            workspace[index] = -0.5 / pivot
            moments[index] = (
                3.0 * (values[index + 1] - 2.0 * values[index] + values[index - 1])
                - moments[index - 1] / 2.0
            ) / pivot
        for index in range(size - 2, 0, -1):
            moments[index] = workspace[index] * moments[index + 1] + moments[index]
        return moments

    @classmethod
    def _spline(cls, x: float, values: np.ndarray) -> float:
        values = np.asarray(values, dtype=np.float64)
        moments = cls._moments(values)
        size = len(values)
        if x < 1.0:
            return float(values[0] + (x - 1.0) * (values[1] - values[0] - moments[1] / 6.0))
        if x > size:
            return float(values[-1] + (x - size) * (values[-1] - values[-2] + moments[-2] / 6.0))
        lower_one_based = int(x)
        fraction = x - lower_one_based
        lower = lower_one_based - 1
        return float(
            values[lower]
            + fraction
            * (
                values[lower + 1] - values[lower] - moments[lower] / 3.0 - moments[lower + 1] / 6.0
                + fraction * (moments[lower] / 2.0 + fraction * (moments[lower + 1] - moments[lower]) / 6.0)
            )
        )

    def undulation_m(self, latitude: float, longitude: float) -> float:
        if not -90.0 < latitude < 90.0:
            raise ValueError(f"Latitude {latitude} is outside EGM96's supported interpolation interior.")
        longitude = longitude % 360.0
        ri = (latitude + 90.0) / GRID_SPACING_DEG
        rj = (longitude + GRID_PADDING * GRID_SPACING_DEG) / GRID_SPACING_DEG
        row0 = int(ri) - 1
        col0 = int(rj) - 1
        if row0 != self.row0 or col0 != self.col0:
            raise ValueError('Point leaves the frozen local EGM96 grid patch')
        x_lon = rj - col0 + 1.0
        x_lat = ri - row0 + 1.0
        row_values = [self._spline(x_lon, self._grid[index, :]) for index in range(4)]
        return self._spline(x_lat, np.asarray(row_values, dtype=np.float64))


def terms(l,p,h):
    return np.array([1,l,p,h,l*p,l*h,p*h,l*l,p*p,h*h,l*p*h,l**3,l*p*p,l*h*h,l*l*p,p**3,p*h*h,l*l*h,p*p*h,h**3])

class RPC:
    def __init__(self,path):
        with np.load(path) as d:
            self.v={k:d[k] for k in d.files if not k.startswith('crop_')}
            self.row0=int(d['crop_row0']) if 'crop_row0' in d else 0;self.col0=int(d['crop_col0']) if 'crop_col0' in d else 0
    def project(self,ll,h):
        v=self.v;t=terms((ll[1]-v['LONG_OFF'])/v['LONG_SCALE'],(ll[0]-v['LAT_OFF'])/v['LAT_SCALE'],(h-v['HEIGHT_OFF'])/v['HEIGHT_SCALE'])
        row=t@v['LINE_NUM_COEFF']/(t@v['LINE_DEN_COEFF'])*v['LINE_SCALE']+v['LINE_OFF']+self.row0
        col=t@v['SAMP_NUM_COEFF']/(t@v['SAMP_DEN_COEFF'])*v['SAMP_SCALE']+v['SAMP_OFF']+self.col0
        return np.array([col,row])
    def inverse(self,colrow,h,initial):
        initial=np.asarray(initial,float)
        # Optimize millidegree increments, rather than poorly scaled degrees.
        fun=lambda u:self.project(initial+u*.001,h)-colrow
        sol=least_squares(fun,np.zeros(2),xtol=1e-13,ftol=1e-13,gtol=1e-10,max_nfev=100)
        ll=initial+sol.x*.001;err=np.linalg.norm(self.project(ll,h)-colrow)
        if err>1e-5:raise RuntimeError(f'RPC inverse failed: {err} pixels')
        return ll,err

def en(a,b):
    lat=np.deg2rad((a[0]+b[0])/2)
    n=111132.92-559.82*np.cos(2*lat)+1.175*np.cos(4*lat)-.0023*np.cos(6*lat)
    e=111412.84*np.cos(lat)-93.5*np.cos(3*lat)+.118*np.cos(5*lat)
    return np.array([(b[1]-a[1])*e,(b[0]-a[0])*n])
