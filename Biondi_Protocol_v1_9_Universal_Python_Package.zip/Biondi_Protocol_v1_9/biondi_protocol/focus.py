"""Configurable v1.9 time-variant phase and exhaustive window fitting."""
import numpy as np
from .statistics import statistics, all_windows, from_statistics


def layer_integral(depth_m, model):
    """Integral from surface to z of ds / phase_length(s); dimensionless."""
    z = np.asarray(depth_m, dtype=float)
    if np.any(~np.isfinite(z)) or np.any(z < 0):
        raise ValueError('Depths must be finite and nonnegative')
    layers = model['layers']
    result = np.zeros_like(z); top = 0.0
    for index, layer in enumerate(layers):
        length = float(layer['phase_length_m'])
        bottom = layer['bottom_m']
        if length <= 0 or not np.isfinite(length):
            raise ValueError('Each propagation phase length must be positive')
        if bottom is None:
            if index != len(layers) - 1:
                raise ValueError('Only the final layer may be unbounded')
            bottom = np.inf
        bottom = float(bottom)
        if bottom <= top:
            raise ValueError('Layer boundaries must strictly increase')
        result += np.clip(z - top, 0, bottom - top) / length
        top = bottom
    if not layers or np.any(z > top):
        raise ValueError('Depth profile does not cover the requested grid')
    return result


def depth_grid(model):
    lo, hi, step = (float(model[k]) for k in ('depth_min_m', 'depth_max_m', 'depth_step_m'))
    if not (0 <= lo <= hi and step > 0):
        raise ValueError('Invalid depth grid')
    count = int(round((hi - lo) / step)) + 1
    if not np.isclose(lo + (count - 1) * step, hi, atol=1e-10):
        raise ValueError('Depth endpoints must lie on the supplied step grid')
    return np.round(lo + np.arange(count) * step, 12)


def time_variant_rate(baseline_m, time_s, slant_range_m, incidence_deg):
    """All arrays [K,N]; time_s is seconds since one acquisition start."""
    b, t, r, theta = np.broadcast_arrays(baseline_m, time_s, slant_range_m, incidence_deg)
    if b.ndim != 2 or b.shape[0] < 2 or not all(np.isfinite(a).all() for a in (b,t,r,theta)):
        raise ValueError('Geometry must be finite [K,N], K>=2')
    db = np.empty_like(b, dtype=float); dt = np.empty_like(t, dtype=float)
    db[1:] = np.diff(b, axis=0); db[0] = db[1]
    dt[1:] = np.diff(t, axis=0); dt[0] = dt[1]
    sine = np.sin(np.deg2rad(theta))
    if np.any(dt == 0) or np.any(r <= 0) or np.any(sine <= 0):
        raise ValueError('Invalid time increments, range or incidence')
    # Match the verified arithmetic order. (m / m) / seconds * seconds.
    return 4 * np.pi * db / (r * sine) / dt * t


def pixel_support(best, support):
    """Keep all members of positive runs >= support; no shared start zone."""
    n = best.shape[0]; support = int(support)
    if support < 1 or support > n:
        raise ValueError('Pixel support must lie in [1, number of positions]')
    positive = np.isfinite(best) & (best > 0); keep = np.zeros_like(positive)
    for start in range(n - support + 1):
        shared = positive[start:start+support].all(axis=0)
        keep[start:start+support] |= shared[None,:]
    return keep


def focus(q_pixels, spacings_m, rate, depths, integral, settings, progress=None):
    """q [N,K,2] ordered range,azimuth; rate [K,N]. Full processing."""
    q = np.asarray(q_pixels); spacing = np.asarray(spacings_m, dtype=float)
    if q.ndim != 3 or q.shape[2] != 2 or spacing.shape != (2,) or np.any(spacing <= 0) or not np.isfinite(spacing).all():
        raise ValueError('q must be [N,K,2], with positive [range,azimuth] spacings')
    n,k,_ = q.shape; rate = np.asarray(rate, dtype=float)
    if rate.shape != (k,n) or not np.isfinite(q).all() or not np.isfinite(rate).all():
        raise ValueError('q and geometry shape/finite check failed')
    depths = np.asarray(depths); integral = np.asarray(integral)
    if depths.ndim != 1 or integral.shape != depths.shape or not np.isfinite(integral).all():
        raise ValueError('Depth grid and layer integral must have matching finite shapes')
    w = int(settings['window_vectors']); p = int(settings['pixel_support'])
    threshold = settings.get('axis_ratio_min'); chunk = int(settings.get('depth_chunk',25))
    if not (3 <= w <= k) or chunk < 1 or (threshold is not None and not 0 <= threshold < 1):
        raise ValueError('Invalid window, chunk or b/a threshold')
    y = q * spacing[None,None,:]
    best = np.full((n,len(depths)), -np.inf); starts = np.full(best.shape,-1,np.int32)
    for low in range(0,len(depths),chunk):
        high = min(len(depths), low+chunk)
        phase = rate.T[:,None,:] * integral[None,low:high,None]
        st = statistics(y,np.cos(phase),np.sin(phase),np.ones(k,bool))
        windows = all_windows(st,w)
        with np.errstate(divide='ignore', invalid='ignore'):
            score, ba, _ = from_statistics(windows, windows)
        eligible = score if threshold is None else np.where(ba > threshold,score,-np.inf)
        best[:,low:high] = eligible.max(axis=0)
        starts[:,low:high] = eligible.argmax(axis=0)
        if progress: progress(high,len(depths))
    support = pixel_support(best,p)
    score = np.where(support,best,0).astype(np.float32)
    return dict(score=score,best_eligible_score=best,winning_start_index=np.where(support,starts,-1),pixel_support_mask=support,depth_m=depths,layer_integral=integral)
