"""Command-line entry points for complete processing and portable restarts."""
import argparse,json,hashlib
from pathlib import Path
import numpy as np
from .focus import depth_grid,layer_integral,focus,time_variant_rate


def load_config(path):
    path=Path(path).resolve();c=json.loads(path.read_text())
    if c.get('protocol_version')!='1.9':raise ValueError('Expected protocol_version 1.9')
    for section,keys in [('source',['path']),('geometry',['orbit_path','scene_path'])]:
        for key in keys:
            value=c.get(section,{}).get(key)
            if value is not None:c[section][key]=str((path.parent/value).resolve())
    return c


def arrays(path):
    with np.load(path,allow_pickle=False) as d:return {k:d[k] for k in d.files}


def plot_result(data,path,label='Biondi Protocol v1.9'):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    a=data['score'];z=data['depth_m'];x=data.get('distance_m',np.arange(len(a)))
    if len(z)<2 or len(x)<2:raise ValueError('Plotting needs at least two depths and positions')
    # pcolormesh respects an exact final endpoint with a shorter final interval.
    xe=np.r_[x[0]-(x[1]-x[0])/2,(x[:-1]+x[1:])/2,x[-1]+(x[-1]-x[-2])/2]
    ze=np.r_[z[0]-(z[1]-z[0])/2,(z[:-1]+z[1:])/2,z[-1]+(z[-1]-z[-2])/2]
    cmap=plt.get_cmap('magma').copy();cmap.set_bad('black');fig,ax=plt.subplots(figsize=(16,6),layout='constrained')
    im=ax.pcolormesh(xe,ze,np.ma.masked_less_equal(a.T,0),shading='flat',cmap=cmap,vmin=0,vmax=float(a.max()) or 1,rasterized=True)
    ax.set_ylim(float(z[-1]),0);ax.set_xlabel('Along-line distance (m)');ax.set_ylabel('Nominal depth (m)');ax.set_title(label);fig.colorbar(im,ax=ax).set_label('Adjusted R² (black = zero / unsupported)');fig.savefig(path,dpi=170);plt.close(fig)


def run_focus(data,config,out,use_saved=False):
    out=Path(out);out.mkdir(parents=True,exist_ok=True);grid=depth_grid(config['depth_model'])
    if use_saved:
        original=data['depth_m'];indices=np.searchsorted(original,grid);indices=np.minimum(indices,len(original)-1)
        # Locate closest grid member, allowing representation roundoff.
        indices=np.where((indices>0)&(abs(original[np.maximum(0,indices-1)]-grid)<abs(original[indices]-grid)),indices-1,indices)
        if not np.allclose(original[indices],grid,atol=1e-10,rtol=0):raise ValueError('Saved grid does not contain requested depths')
        grid=original[indices];integral=data['layer_integral'][indices];model_source='saved input phase integral'
    else:integral=layer_integral(grid,config['depth_model']);model_source='configured layer model'
    rate=data.get('phase_geometry_rate_times_elapsed')
    if rate is None:rate=time_variant_rate(data['baseline_perp_m'],data['acquisition_elapsed_time_s'],data['slant_range_m'],data['local_incidence_angle_deg'])
    result=focus(data['q'],data['range_azimuth_spacing_m'],rate,grid,integral,config['inversion'],lambda done,total:print(json.dumps({'depths':done,'total':total}),flush=True) if done%100==0 or done==total else None)
    result['distance_m']=data.get('distance_m',np.arange(len(result['score']),dtype=float));result['position_index']=np.arange(len(result['score']))
    result['phase_geometry_rate_times_elapsed']=rate
    np.savez_compressed(out/'result.npz',**result)
    score=result['score'];n,k,_=data['q'].shape;w=int(config['inversion']['window_vectors']);positive=result['pixel_support_mask'];peak=None
    if positive.any():
        p,d=np.unravel_index(score.argmax(),score.shape);peak={'position_index':int(p),'distance_m':float(result['distance_m'][p]),'nominal_depth_m':float(grid[d]),'adjusted_R2':float(score[p,d])}
    report={'protocol_version':'1.9.0','configuration':config,'depth_model_source':model_source,'coverage':{'full':True,'positions':n,'pairs':k,'window_starts':k-w+1,'vectors_per_fit':w,'depths':len(grid)},'positive_cells':int(positive.sum()),'positive_fraction':float(positive.mean()),'peak':peak,'mode_Track_sector_minor_axis_and_heldout_gates':False,'score':'no-offset two-component ellipse fit in metres; adjusted R²; unsupported/nonpositive cells displayed as zero; raw best scores preserved','phase_geometry':'finite-difference baseline rate times seconds since common acquisition start'}
    (out/'report.json').write_text(json.dumps(report,indent=2));(out/'resolved_config.json').write_text(json.dumps(config,indent=2))
    plot_result(result,out/'tomogram.png',f"{config['name']} · v1.9 · W={w}, P={config['inversion']['pixel_support']}")
    return result,report


def main(argv=None):
    parser=argparse.ArgumentParser(description='Biondi Protocol v1.9: configurable all-window depth fitting')
    sub=parser.add_subparsers(dest='command',required=True)
    for command in ('focus','run','measure'):
        p=sub.add_parser(command);p.add_argument('--config',required=True);p.add_argument('--out',required=True)
        if command=='focus':p.add_argument('--input',required=True);p.add_argument('--use-saved-depth-model',action='store_true')
    p=sub.add_parser('plot');p.add_argument('--input',required=True);p.add_argument('--output',required=True);p.add_argument('--label',default='Biondi Protocol v1.9')
    args=parser.parse_args(argv)
    if args.command=='plot':plot_result(arrays(args.input),args.output,args.label);return
    c=load_config(args.config);out=Path(args.out);out.mkdir(parents=True,exist_ok=True)
    if args.command=='focus':run_focus(arrays(args.input),c,out,args.use_saved_depth_model);return
    from .measurement import measure
    scene=arrays(c['geometry']['scene_path']);bankconfig=dict(c['bank']);bankconfig['azimuth_sampling_hz']=c['sensor']['azimuth_sampling_hz']
    bank,report=measure(scene,c['source'],bankconfig,c['registration'],lambda group,done,total:print(json.dumps({'group':group,'pair':done,'pairs':total}),flush=True) if done==1 or done%25==0 or done==total else None)
    np.savez_compressed(out/'bank.npz',**bank);(out/'bank_report.json').write_text(json.dumps(report,indent=2))
    if args.command=='measure':return
    from .geometry import from_orbit
    geom=from_orbit(arrays(c['geometry']['orbit_path']),scene,bank['midpoint_hz'],c['sensor'],c['geometry']);np.savez_compressed(out/'geometry.npz',**geom)
    spacing=np.asarray(c['sensor']['range_azimuth_spacing_m'],dtype=float)
    data={'q':bank['q'],'range_azimuth_spacing_m':spacing,'distance_m':scene['distance_m'],**geom}
    np.savez_compressed(out/'input.npz',**data);run_focus(data,c,out)

if __name__=='__main__':main()
