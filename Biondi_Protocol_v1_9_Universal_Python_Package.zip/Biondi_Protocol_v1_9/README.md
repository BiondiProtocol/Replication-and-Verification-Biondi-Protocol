# Biondi Protocol v1.9.0

A configurable, dataset-independent implementation of the current Biondi-like
SAR displacement/depth-fitting workflow. All executable Python is included.
No previous chat, `/tmp` file, notebook state or network service is needed.

## Start after a restart

Extract this ZIP, enter `Biondi_Protocol_v1_9`, then:

```bash
python -m pip install -r requirements.txt
python run_protocol.py focus --config examples/giza_reference.json --input examples/reference_input.npz --out reference_run --use-saved-depth-model
python -m unittest discover -s tests -v
python verify_reference.py --out reference_validation
```

The first command reproduces the full saved north-line depth fit. The fixture is
an explicitly named reference example, not a requirement of the protocol.
All 217 positions, 295 pairs, 121 window starts and 999 depths are included.
The restart reproduces every displayed score and support decision exactly.
`reference_run` contains `result.npz`, `report.json`, `resolved_config.json`
and `tomogram.png`. See `provenance/validation_saved.json`.

Remove `--use-saved-depth-model` to recompute the phase integral from JSON.
The configured reference model preserves all support decisions; the largest
score difference from the historical fixture is approximately 7.45e-9.

Optional installation as a Python package:

```bash
python -m pip install ".[io]"
biondi-protocol --help
```

## What is universal

The code accepts arbitrary position counts, bank sizes, aperture windows,
mask widths, Doppler leaps, component pixel spacings, context/core dimensions,
window lengths, b/a thresholds, pixel-support lengths and layer profiles.
There is no Khafre coordinate, X33 sensor identifier, 217-position limit or
K=295 requirement in the processing core. `axis_ratio_min: null` disables the
ellipse-ratio gate. Pixel support P=1 admits isolated positive fits.

The example K295/W175/P8/b/a>0.1 settings are one reference preset. No global
optimum is claimed. Held-out experiments are optional research diagnostics,
not part of canonical v1.9 eligibility. Mode, Track, central-sector and
minor-axis gates are absent from this implementation.

## Geological model note

The supplied reference depth model is based on the adopted layered
representation of **Giza Mokattam limestone**. Its boundaries and propagation
phase lengths are site-specific assumptions, not universal material constants.
Other sites require an appropriate replacement profile.

The currently adopted Giza reference has a 2.4 m boundary, with effective phase
lengths 0.036858797794585174 m above and 0.08074816571554078 m below. These are
the exact coefficients used in the recent reference runs. They are distinct
from radar carrier wavelength, image pixel spacing and spatial resolution.
Do not silently substitute earlier calibration coefficients. The layer model
integrates from the surface to each nominal depth; details are in METHODS.md.

## Rebuild from a complex SLC

Create scene and orbit arrays according to INPUT_SCHEMA.md and fill in JSON.
Native sensor metadata must be mapped explicitly into that common schema;
provider-specific automatic metadata parsing is not assumed.

```bash
python run_protocol.py run --config your_config.json --out your_run
```

This command reads the complex SLC, builds every requested R/O pair, runs a
planted registration control, measures every target and flank, removes the
flank reference, reconstructs geometry and evaluates every window/depth.
The output also preserves `bank.npz`, `bank_report.json`, `geometry.npz` and
`input.npz` for a subsequent restart.

Supported explicit readers: HDF5 split I/Q, HDF5 complex dataset, complex NPY,
and memory-mappable complex TIFF. TIFFs that cannot be memory-mapped need
conversion or a reader adapter. Input must be a complex SLC in native azimuth
row/range column order; an intensity image or GRD is insufficient.

`examples/reference_slc_rebuild.json` is a concrete sensor/scene example that
uses the source crop saved separately with the reference work. Place its
`Khafre_Pyramid_0p7s_WorkingCrop.h5` next to that configuration. The raw SLC
is not included here. Its orbit and scene arrays are included. All relative
source/scene/orbit paths resolve relative to the configuration file.

For regional corner-to-corner placement using supplied standard RPCs:

```bash
python make_scene.py --corners your_corners.json --rpc your_rpc.npz --out your_scene.npz
```

Use `--geoid-grid` for a supplied local EGM96 grid and orthometric endpoint
heights. Otherwise provide ellipsoid heights. This helper preserves the
regional straight-line approximation used in the reference workflow; for long
or geographically complex lines, supply scene arrays from your geolocation
processor. Never reuse a Giza geoid patch elsewhere.

Measurement alone and replotting:

```bash
python run_protocol.py measure --config your_config.json --out your_bank
python run_protocol.py plot --input your_run/result.npz --output your_plot.png --label "Your line"
```

## Verification scope

- Full reference depth fit: all scores and masks reproduced exactly using saved inputs.
- Full reference orbit geometry: all 217 positions and 295 looks compared with the historical geometry; see validation_geometry.json.
- Configured geological profile: independently recomputed and compared across the full depth grid.
- Direct least-squares comparison, arbitrary dimensions, time-unit cancellation,
  pixel-support behavior, planted registration and compact/full inverse-DFT bank
  equivalence: tested on synthetic inputs.
- The generalized SLC-reader/bank path was tested on a synthetic complex SLC;
  the large reference SLC was not rebuilt again during this packaging task.
  The prior verified reader/bank source and its original checks are preserved
  in `provenance/verified_reference_source.zip`.

## Files and continuity

- `biondi_protocol/`: all current Python processing modules.
- `run_protocol.py`: command-line entry point, usable without installing the package.
- `make_scene.py`: optional RPC/geoid placement helper.
- `verify_reference.py`: complete reference inversion/orbit conformance checks.
- `examples/`: editable JSON, restart fixtures and canonical orbit/scene example.
- `METHODS.md`: equations, signs, units and scoring.
- `INPUT_SCHEMA.md`: sensor-independent array contract.
- `CHANGELOG.md`: changes from v1.8 and explicit compatibility boundaries.
- `tests/`: executable verification tests.
- `provenance/`: reference source and validation reports.

The reference source ZIP is historical provenance, not the universal entry
point. Use the top-level v1.9 Python files for new datasets. Analysis fixture
NPZs contain derived measurements and reference results, not a raw SLC.
