# Changes from v1.8 to v1.9.0

- Formalized the current Biondi-like finite-difference time-variant depth phase.
- Fixed the meaning of acquisition elapsed time across all sub-aperture designs.
- Retained component conversion to metres for current ellipse/depth fitting.
- Configurable layered surface-to-depth phase integral; explicit Giza Mokattam
  limestone reference assumptions.
- Every window start is evaluated; strongest eligible window wins independently
  at each position/depth. No first-start-only restriction.
- Current pixel support admits complete positive runs; no shared-start zones.
- Canonical eligibility no longer uses mode, Track, central-sector or minor-axis
  gates. b/a is optional and applied before winner selection.
- Configurable bank size, mask, leap, support/core, flank sampling, W and P.
- Portable scene/orbit/SLC interface and restart arrays; full Python included.
- Preserved contextual registration then shift-then-crop refinement.
- Separated full canonical fitting from optional held-out diagnostics.
- Recorded coverage and preserved unsupported/negative raw best scores.
- Included full-reference conformance reports and original verified source.

v1.8 settings and gated results are not silently reinterpreted as v1.9. The
historical source snapshot is retained for provenance; old hard-coded scripts
are not the new universal entry point. Regional RPC line placement remains an
optional adapter with its documented approximation. Automated parsers for all
sensor vendors and a universal geological depth calibration are not claimed.

Version label 1.9.0 denotes the implemented protocol release in this archive.
This packaging task did not publish or update any external repository.
