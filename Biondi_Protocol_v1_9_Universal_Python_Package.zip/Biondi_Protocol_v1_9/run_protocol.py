"""Run directly after extracting the ZIP; no package installation required."""
import os
for name in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):
    os.environ[name]='1'
from biondi_protocol.cli import main
if __name__=='__main__':main()
